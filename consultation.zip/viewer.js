'use strict';
const AWW_ANNUAL_VIEW=(()=>{function windowStats(rows,from,to){
 const lower=date=>{let a=0,b=rows.length;while(a<b){const m=(a+b)>>1;if(rows[m][0]<date)a=m+1;else b=m;}return a;};
 const first=from&&to?lower(from):rows.length,last=from&&to?lower(to+'\uffff')-1:-1;
 if(first>last)return {from:null,to:null,performance:[0,1,2].map(()=>({stats:{cagr:null,maxDrawdown:null,troughDate:null},mae:null}))};
 const a=rows[first],b=rows[last],years=(Date.parse(b[0])-Date.parse(a[0]))/(365.2425*86400000);
 const performance=[1,2,3].map(column=>{
  let peak=a[column],dd=0,troughDate=null,mae=null;
  for(let j=first;j<=last;j++){
   const r=rows[j],value=r[column];peak=Math.max(peak,value);
   const loss=peak>0?100*(value/peak-1):0;
   if(loss<dd){dd=loss;troughDate=r[0];}
   const adverse=column===1?null:r[column+2];
   if(Number.isFinite(adverse)&&(!mae||adverse<mae.percent))mae={percent:adverse,date:r[0]};
  }
  const cagr=years>0&&a[column]>0&&b[column]>=0?100*(Math.pow(b[column]/a[column],1/years)-1):null;
  // New exports carry two public outcome flags, never private signal rules.
  // Legacy six-column exports retain their old reducer until refreshed.
  if(column>1&&a.length>=8&&!rows.slice(first,last+1).some(r=>r[column+4]===1))mae=null;
  return {stats:{from:a[0],to:b[0],cagr,maxDrawdown:dd,troughDate},mae};
 });
 return {from:a[0],to:b[0],performance};
}
/** Display an interval only as far as the visible right endpoint. Completed
 * values use exact execution observations supplied by the private observer;
 * an unfinished / clipped interval reads existing DAILY capital closes.
 * Both colours use system return minus unlevered Nasdaq, in percentage points.
 * No signals, thresholds or fund rules are calculated by this public helper.
 */
function periodValues(period,rows,to){
 if(period.complete&&period.to<=to)return {values:period.values,partial:false};
 let lo=0,hi=rows.length;while(lo<hi){const mid=(lo+hi)>>1;if(rows[mid][0]<=to)lo=mid+1;else hi=mid;}
 const row=rows[lo-1];if(!row||row[0]<period.from)return null;
 const returns=period.bases.map((base,i)=>base>0?100*(row[i+1]/base-1):null);
 return {values:returns.slice(1).map((v,i)=>period.tone==='b'&&i===0?null:v!==null&&returns[0]!==null?v-returns[0]:null),partial:true};
}
/** Compact one-line rail above the plot, shared verbatim by PC/public reader.
 * Whole-history / phone views cannot fit every short interval's text. Preserve
 * its coloured tick and reveal that interval on hover/touch, or when zoomed.
 * Prioritise the pointed interval, then red intervals, then available width;
 * never overlap labels or cover the capital curves or right-axis heading.
 */
function drawPeriods(c,m,g,x,indexAt,hoverDay,visible=true){
 m.periodLabels=[];m.periodTicks=[];if(!visible||!m.capitalPeriods?.length)return;
 const from=m.windowPerformance?.from,to=m.windowPerformance?.to;if(!from||!to)return;
 const small=g.w<600,font=(small?'600 10px':'600 11px')+' Segoe UI,Arial,sans-serif';
 c.save();c.font=font;c.textAlign='center';c.textBaseline='middle';
 // This rail is outside the cached plot. Clear it on hover too, without
 // repainting price data or the axis title at top - 11.
 c.clearRect(g.left,0,g.right-g.left,31);
 const signed=v=>Number.isFinite(v)?(v>0?'+':'')+v.toLocaleString('fr-FR',{minimumFractionDigits:1,maximumFractionDigits:1}):'—';
 const candidates=[];
 for(const p of m.capitalPeriods){
  if(p.from>to||p.to<from)continue;
  const left=Math.max(g.left,x(indexAt(p.from))),right=Math.min(g.right,p.complete?x(indexAt(p.to)):g.right);
  if(right<=left)continue;
  const observation=periodValues(p,m.windowData,to);if(!observation)continue;
  // Same inverse fund, but entry dates can now differ. Show the selected
  // system's observed difference; retain both values for audits.
  const suffix=observation.partial?'*':'',lines=['Δ '+signed(observation.values[m.periodSystemIndex??(p.tone==='r'?0:1)])+' pt'+suffix];
  const width=Math.max(...lines.map(s=>c.measureText(s).width))+10,center=(left+right)/2,color=p.tone==='r'?'#ad4052':'#246fa9';
  const tick={from:p.from,to:p.to,tone:p.tone,left,right,center,color};m.periodTicks.push(tick);
  c.strokeStyle=color;c.globalAlpha=.55;c.lineWidth=2;c.beginPath();c.moveTo(center,g.top-5);c.lineTo(center,g.top);c.stroke();c.globalAlpha=1;
  candidates.push({...tick,lines,width,partial:observation.partial,values:observation.values,hover:!!hoverDay&&hoverDay>=p.from&&(hoverDay<p.to||!p.complete)});
 }
 candidates.sort((a,b)=>Number(b.hover)-Number(a.hover)||Number(b.tone==='r')-Number(a.tone==='r')||(b.right-b.left)-(a.right-a.left));
 for(const p of candidates){
  const left=Math.max(g.left,Math.min(g.right-p.width,p.center-p.width/2)),right=left+p.width;
  if(right>g.right||m.periodLabels.some(l=>left<l.right+5&&right>l.left-5))continue;
  const center=(left+right)/2,top=7,bottom=20;
  c.fillStyle=p.tone==='r'?'rgba(193,77,91,.06)':'rgba(22,117,197,.06)';c.fillRect(left,top,p.width,bottom-top);
  c.fillStyle=p.color;p.lines.forEach((line,i)=>c.fillText(line,center,top+7+i*13));
  c.strokeStyle=p.color;c.lineWidth=.7;c.globalAlpha=.5;c.beginPath();c.moveTo(center,bottom+2);c.lineTo(p.center,g.top-5);c.stroke();c.globalAlpha=1;
  m.periodLabels.push({...p,left,right,top,bottom});
 }c.restore();
}
/** H4 result, from the true entry base even when entry lies outside the zoom.
 * Final executions are separate from marks: at a reversal the exit-bar close
 * already includes the NEXT position. A clipped/open period reads only marks
 * known by `to`; the full-history final return must not leak into that prefix.
 */
function h4PeriodValues(period,series,to){
 if(to<period.from)return null;
 if(period.complete&&period.to<=to)return {values:period.values,partial:false};
 const values=series.map((s,j)=>{
  const ps=s.points;let lo=0,hi=ps.length;
  while(lo<hi){const mid=(lo+hi)>>1;if(ps[mid].date<=to)lo=mid+1;else hi=mid;}
  const row=ps[lo-1],base=period.bases[j];
  return row&&row.date>=period.from&&base>0?100*(row.v/base-1):null;
 });
 return {values,partial:true};
}
/** Read-only H4 window statistics from existing marked capital and entry bases.
 * No price/trade reconstruction: exits use their already-accounted result,
 * because the exit-bar close may belong to a new position. MAE samples H4
 * closes plus final executions, not unknown intrabar paths. Entry bases survive
 * a clipped window and partial TP. A depleted account cannot start a new MAE.
 */
function h4WindowStats(series,periods,from,to){
 const performance=series.map((s,j)=>{
  const points=s.points.filter(p=>p.date>=from&&p.date<=to&&Number.isFinite(p.v));
  const first=points[0],last=points.at(-1);let peak=first?.v,dd=0,mae=null,ddDate=null,maeDate=null;
  for(const p of points){peak=Math.max(peak,p.v);const v=peak>0?100*(p.v/peak-1):0;if(v<dd){dd=v;ddDate=p.date;}}
  const observe=(v,date)=>{if(Number.isFinite(v)){if(v<(mae??0))maeDate=date;mae=Math.min(mae??0,0,v);}};
  for(const period of periods){
   const base=period.bases[j];if(!(base>0)||period.from>to||period.to<from)continue;
   for(const p of points)if(p.date>=period.from&&(p.date<period.to||!period.complete&&p.date===period.to))observe(100*(p.v/base-1),p.date);
   if(period.complete&&period.to>=from&&period.to<=to)observe(period.values[j],period.to);
  }
  const years=first&&last?(Date.parse(last.date)-Date.parse(first.date))/(365.2425*86400000):0;
  const cagr=years>0&&first.v>0&&last.v>=0?100*(Math.pow(last.v/first.v,1/years)-1):null;
  return {from:first?.date||null,to:last?.date||null,cagr:Number.isFinite(cagr)?cagr:null,maxDrawdown:first?dd:null,mae,ddDate,maeDate};
 });
 return {from:performance[0]?.from||null,to:performance[0]?.to||null,performance};
}
/** Price-axis readout only, shared with the public viewer. `right` is the
 * exclusive viewport endpoint (including fractional pan), not the hover date.
 * The peak is fixed by the model over its full source, never the zoom window.
 * Above that peak a new high would have no drawdown. No trading rule is read. */
/** Hollow extrema at their true curve coordinates. White under-stroke keeps
 * markers legible over intersecting curves; no displaced text or leaders. */
function drawRiskSymbol(c,x,y,kind,color,u=1){
 c.save();c.setLineDash([]);c.beginPath();if(kind==='DD')c.arc(x,y,4*u,0,2*Math.PI);else{c.moveTo(x,y-5*u);c.lineTo(x+5*u,y+4*u);c.lineTo(x-5*u,y+4*u);c.closePath();}c.strokeStyle=color;c.lineWidth=1.5*u;c.stroke();c.restore();
}
function drawRiskLegendLine(c,text,x,y,color,u=1){
 c.save();c.fillStyle=color;c.textAlign='left';c.textBaseline='middle';let xx=x;
 for(const part of text.split(/([○△])/)){
  if(part==='○'||part==='△'){drawRiskSymbol(c,xx+5*u,y,part==='○'?'DD':'MAE',color,u);xx+=12*u;}
  else{c.fillText(part,xx,y);xx+=c.measureText(part).width;}
 }c.restore();
}
function drawEquitySymbols(c,m,g,marks){
 const u=1/(g.uiScale||1),r=4*u;m.equityMarkLayout=[];
 c.save();c.beginPath();c.rect(g.left,g.top,g.right-g.left,g.bottom-g.top);c.clip();
 for(const mark of marks){const {x,y,kind}=mark;if(!Number.isFinite(x+y)||x<g.left-r||x>g.right+r||y<g.top-r||y>g.bottom+r)continue;
  const path=()=>{c.beginPath();if(kind==='DD')c.arc(x,y,r,0,Math.PI*2);else{c.moveTo(x,y-r-1*u);c.lineTo(x+r+1*u,y+r);c.lineTo(x-r-1*u,y+r);c.closePath();}};
  c.setLineDash([]);path();c.strokeStyle='#fff';c.lineWidth=3.5*u;c.stroke();path();c.strokeStyle=mark.color;c.lineWidth=1.5*u;c.stroke();
  m.equityMarkLayout.push({...mark,shape:kind==='DD'?'circle':'triangle',left:x-r-2*u,right:x+r+2*u,top:y-r-2*u,bottom:y+r+2*u,opacity:1});
 }c.restore();
}
function drawH4Extremes(c,m,g,x,y,indexAt){
 const marks=[];for(const [i,p]of (m.h4WindowPerformance?.performance||[]).entries())for(const [kind,date,percent]of [['DD',p.ddDate,p.maxDrawdown],['MAE',p.maeDate,p.mae]]){
  if(!date||!(percent<0))continue;const point=m.series[i].points.find(q=>q.date>=date&&Number.isFinite(q.v));if(!point)continue;
  marks.push({key:m.series[i].key||String(i),kind,date,plotDate:point.date,percent,color:m.series[i].color,x:x(point.idx??point.i??indexAt(point.date)),y:(m.seriesY?.[i]||y)(point.v)});
 }drawEquitySymbols(c,m,g,marks);
}
function cursorDrawdown(peak,value,right,total){
 if(!Number.isFinite(peak)||peak<=0||!Number.isFinite(value)||value<0||!(total>0)||right<total-1e-7)return null;
 const percent=Math.min(0,100*(value/peak-1)),rounded=Math.round(percent*100)/100;
 return {peak,value,percent,text:(rounded<0?'−':'')+Math.abs(rounded).toLocaleString('fr-FR',{minimumFractionDigits:2,maximumFractionDigits:2})+' %'};
}
/** Same compact, bottom-right overlay for private/public H4. Text is sized in
 * screen pixels even on the private mobile Canvas. The public reader receives
 * no extra field or rule; C1/C2 keep its existing abbreviated presentation. */
/** Compact phone table; read-only formatting of already computed results.
 * Explicit columns avoid repeating CAGR/MDD/MAE on every line. All dimensions
 * are screen pixels, independent of the private canvas' virtual width. */
function compactPerformanceCard(c,g,rows,period){
 const u=1/(g.uiScale||1),pad=6*u,gap=9*u,font=10*u+'px Segoe UI,Arial,sans-serif';
 const number=v=>Number.isFinite(v)?v.toLocaleString('fr-FR',{minimumFractionDigits:1,maximumFractionDigits:1}):'—';
 const unit=(v,suffix)=>Number.isFinite(v)?number(v)+suffix:'—';
 const header=['','CAGR','DD','MAE'],cells=rows.map(r=>[r.label,unit(r.cagr,' %/an'),unit(r.dd,' %'),unit(r.mae,' %')]);
 c.save();c.font=font;const widths=header.map((h,i)=>Math.max(c.measureText(h).width+(i>1?13*u:0),...cells.map(r=>c.measureText(r[i]).width)));
 let width=Math.max(widths.reduce((a,b)=>a+b,0)+gap*3+2*pad,c.measureText(period).width+2*pad);
 width=Math.min(width,g.right-g.left-8*u);c.restore();
 const right=g.right-4*u,bottom=g.bottom-5*u,height=(31+14*rows.length)*u;
 return {compactTable:true,left:right-width,right,top:bottom-height,bottom,width,height,pad,gap,font,u,header,cells,widths,rows,period};
}
function drawCompactPerformanceCard(c,b){
 const {u,pad}=b;c.save();c.fillStyle='rgba(255,255,255,.94)';c.fillRect(b.left,b.top,b.width,b.height);c.strokeStyle='#dbe2ec';c.lineWidth=u;c.strokeRect(b.left,b.top,b.width,b.height);c.textBaseline='middle';c.font=b.font;
 const xs=[b.left+pad];for(let i=1;i<4;i++)xs[i]=xs[i-1]+b.widths[i-1]+b.gap;
 // Light cell rules separate numeric columns without enlarging the inset.
 const tableBottom=b.top+(17+14*b.cells.length)*u;c.strokeStyle='#e1e7ef';c.lineWidth=.6*u;c.beginPath();
 for(let i=1;i<4;i++){const x=xs[i]-b.gap/2;c.moveTo(x,b.top);c.lineTo(x,tableBottom);}
 for(let i=0;i<=b.cells.length;i++){const y=b.top+(17+14*i)*u;c.moveTo(b.left,y);c.lineTo(b.right,y);}c.stroke();
 const paint=(row,y,color)=>{c.fillStyle=color;row.forEach((t,i)=>{c.textAlign=i?'right':'left';c.fillText(t,i?xs[i]+b.widths[i]:xs[i],y,b.widths[i]);});};
 paint(b.header,b.top+10*u,'#52677c');
 for(const i of [2,3])drawRiskSymbol(c,xs[i]+b.widths[i]-c.measureText(b.header[i]).width-8*u,b.top+10*u,i===2?'DD':'MAE','#52677c',u);b.cells.forEach((r,i)=>paint(r,b.top+(24+14*i)*u,b.rows[i].color));
 c.textAlign='right';c.fillStyle='#697b8c';c.font=9*u+'px Segoe UI,Arial,sans-serif';c.fillText(b.period,b.right-pad,b.bottom-7*u,b.width-2*pad);c.restore();
}
function drawH4Card(c,m,g,from,to,{compact=false,publicView=false}={}){
 const key=from+'|'+to;
 if(m.h4WindowKey!==key){m.h4WindowPerformance=h4WindowStats(m.series,m.h4Periods,from,to);m.h4WindowKey=key;}
 const result=m.h4WindowPerformance,u=1/(g.uiScale||1),small=g.w/u<600,pad=8*u;
 const fmt=v=>Number.isFinite(v)?v.toLocaleString('fr-FR',{minimumFractionDigits:2,maximumFractionDigits:2}):'—';
 const day=d=>d?d.slice(8,10)+'/'+d.slice(5,7)+'/'+d.slice(0,4):'—';
 const lines=result.performance.map((p,i)=>({color:m.series[i].color,main:'CAGR '+(publicView?'C'+(i+1):i?m.series[i].label.replace(/^Capital /,''):'Sans levier')+' : '+fmt(p.cagr)+' %/an',sub:(publicView?'○ MDD':'○ Max Drawdown')+' '+fmt(p.maxDrawdown)+' % · △ MAE '+fmt(p.mae)+' %'}));
 const period='Période : '+day(result.from)+' – '+day(result.to);
 if(small){const rows=result.performance.map((p,i)=>({label:publicView?'C'+(i+1):i?'Lev.':'×1',color:m.series[i].color,cagr:p.cagr,dd:p.maxDrawdown,mae:p.mae}));const b=compactPerformanceCard(c,g,rows,day(result.from)+' – '+day(result.to));m.equityCardBounds={...b,lines};drawCompactPerformanceCard(c,b);return;}
 const mainFont=(small?'700 ':'600 ')+(small?10:12)*u+'px Segoe UI,Arial,sans-serif',subFont='500 '+(small?9:10)*u+'px Segoe UI,Arial,sans-serif';
 c.save();let width=0;c.font=mainFont;for(const l of lines)width=Math.max(width,c.measureText(l.main).width);c.font=subFont;for(const l of lines)width=Math.max(width,c.measureText(l.sub).width);width=Math.max(width,c.measureText(period).width);
 const axisLeft=g.insetAxes?Math.min(g.right,...(m.axisTextBoxes||[]).filter(b=>b.left>g.left+(g.right-g.left)/2).map(b=>b.left-5*u)):g.right;
 const right=g.right-4*u;width=Math.min(width+2*pad,right-g.left-4*u);const height=(24+29*lines.length)*u,bottom=g.bottom-5*u,left=right-width,top=bottom-height;
 m.equityCardBounds={left,right,top,bottom,width,height,lines,period};
 c.fillStyle=compact?'rgba(255,255,255,.9)':'rgba(248,250,253,.94)';c.fillRect(left,top,width,height);c.strokeStyle=compact?'rgba(89,113,138,.2)':'#dbe2ec';c.lineWidth=u;c.strokeRect(left,top,width,height);c.textAlign='left';c.textBaseline='middle';
 lines.forEach((l,i)=>{const y=top+(13+29*i)*u;c.fillStyle=l.color;c.font=mainFont;c.fillText(l.main,left+pad,y,width-2*pad);c.font=subFont;drawRiskLegendLine(c,l.sub,left+pad,y+12*u,l.color,u);});
 c.fillStyle='#52677c';c.font=9*u+'px Segoe UI,Arial,sans-serif';c.fillText(period,left+pad,bottom-9*u,width-2*pad);c.restore();
}
/** H4-only two-line rail. Same source on PC/public/phone. Curve colors identify
 * the two returns; the subtle connector identifies the position's background.
 * Crowded intervals keep a tick; hover/touch gives that interval priority.
 * Work in physical text pixels even on the PC's scaled mobile Canvas.
 */
function drawH4Periods(c,m,g,x,indexAt,from,to,hoverDay){
 m.h4PeriodLabels=[];m.h4PeriodTicks=[];if(!m.h4Periods?.length||!from||!to)return;
 const u=1/(g.uiScale||1),small=g.w/u<600;
 c.save();c.font='600 '+(small?10:11)*u+'px Segoe UI,Arial,sans-serif';c.textAlign='center';c.textBaseline='middle';
 c.clearRect(g.left,0,g.right-g.left,g.top-3*u);
 const signed=v=>Number.isFinite(v)?(v>0?'+':'')+v.toLocaleString('fr-FR',{minimumFractionDigits:1,maximumFractionDigits:1})+' %':'—';
 const candidates=[];
 for(const p of m.h4Periods){
  if(p.from>to||p.to<from)continue;
  const a=x(indexAt(p.from)),b=x(indexAt(p.to)+(p.complete?0:.5));
  if(b<g.left||a>g.right)continue;
  const left=Math.max(g.left,a),right=Math.min(g.right,b),center=(left+right)/2,observation=h4PeriodValues(p,m.series,to);
  if(!observation)continue;
  const lines=observation.values.map(v=>'Δ '+signed(v)+(observation.partial?'*':'')),colors=m.series.map(s=>s.color);
  const width=Math.max(...lines.map(s=>c.measureText(s).width))+8*u,color=p.tone==='v'?'#13846c':'#c14d5b';
  const tick={from:p.from,to:p.to,left,right,center,color};m.h4PeriodTicks.push(tick);
  c.strokeStyle=color;c.globalAlpha=.55;c.lineWidth=1.5*u;c.beginPath();c.moveTo(center,g.top-4*u);c.lineTo(center,g.top);c.stroke();c.globalAlpha=1;
  candidates.push({...tick,lines,colors,width,values:observation.values,partial:observation.partial,hover:!!hoverDay&&hoverDay>=p.from&&(hoverDay<p.to||!p.complete)});
 }
 candidates.sort((a,b)=>Number(b.hover)-Number(a.hover)||(b.right-b.left)-(a.right-a.left));
 for(const p of candidates){
  const left=Math.max(g.left,Math.min(g.right-p.width,p.center-p.width/2)),right=left+p.width;
  if(right>g.right||m.h4PeriodLabels.some(l=>left<l.right+4*u&&right>l.left-4*u))continue;
  const center=(left+right)/2,top=5*u,bottom=top+p.lines.length*13*u;
  p.lines.forEach((line,j)=>{c.fillStyle=p.colors[j];c.fillText(line,center,top+(6+j*13)*u);});
  c.strokeStyle=p.color;c.lineWidth=.6*u;c.globalAlpha=.45;c.beginPath();c.moveTo(center,bottom);c.lineTo(p.center,g.top-4*u);c.stroke();
  c.globalAlpha=1;m.h4PeriodLabels.push({...p,left,right,top,bottom});
 }c.restore();
}
/** Endpoint return of the visible capital window (not CAGR or period Δ).
 * Shared PC/public drawing, using their existing series and coordinate maps.
 * Exclude padded offscreen observations; no rebasing, signal or ledger mutation.
 * A zero starting balance has no defined percentage; a zero ending balance
 * from a positive base is -100%. Thin leaders preserve the exact endpoint when
 * nearby labels need separation. No new public data or trading rule is needed. */
function drawEndGains(c,m,g,curves,x,start,end){
 m.endGainLabels=[];
 const u=1/(g.uiScale||1),height=28*u,gap=3*u,labels=[];
 c.save();c.font=(g.w/u<600?10:11)*u+'px Segoe UI,Arial,sans-serif';c.textBaseline='middle';c.textAlign='right';
 for(const s of curves){
  const valid=p=>(p.idx??p.i)>=start-.5&&(p.idx??p.i)<=end+.5&&Number.isFinite(p.v);
  const first=s.points.find(valid),last=s.points.findLast(valid),base=s.base??first?.v;
  if(!(base>0)||!last)continue;
  const percent=(last.v/base-1)*100,xx=x(last.idx??last.i),yy=s.y(last.v);
  if(!Number.isFinite(percent)||!Number.isFinite(yy)||xx<g.left||xx>g.right||yy<g.top||yy>g.bottom)continue;
  const text=(percent>0?'+':'')+percent.toLocaleString('fr-FR',{maximumFractionDigits:Math.abs(percent)<1000?1:0})+' %',points=s.base>0?100*last.v/s.base:last.v,pointsText=points.toLocaleString('fr-FR',{maximumFractionDigits:1})+' pt',width=Math.max(c.measureText(text).width,c.measureText(pointsText).width)+6*u;
  const right=Math.min(g.right-4*u,Math.max(g.left+width,xx-6*u)),left=right-width;
  labels.push({key:s.key,color:s.color,from:first.date,to:last.date,percent,text,points,pointsText,x:xx,y:yy,left,right,width});
 }
 // Exact ordinate: points above and percentage below a horizontal level.
 // Curves may pass beneath the white text halo. Nearby labels separate in X.
 for(const l of labels.sort((a,b)=>a.y-b.y)){
  let right=Math.min(g.right-5*u,l.x-4*u),left=right-l.width;
  const top=Math.max(g.top,l.y-14*u),bottom=Math.min(g.bottom,l.y+14*u);
  while(m.endGainLabels.some(b=>textBoxesOverlap({left,right,top,bottom},b,3*u))&&left-l.width-8*u>=g.left){right=left-8*u;left=right-l.width;}
  left=Math.max(g.left+2*u,left);right=left+l.width;
  c.strokeStyle=l.color;c.globalAlpha=.6;c.lineWidth=.7*u;c.setLineDash([2*u,3*u]);c.beginPath();c.moveTo(left,l.y);c.lineTo(g.right,l.y);c.stroke();c.setLineDash([]);c.globalAlpha=1;
  c.strokeStyle='rgba(255,255,255,.88)';c.lineWidth=3.5*u;c.fillStyle=l.color;
  for(const [text,dy] of [[l.pointsText,-8*u],[l.text,8*u]]){const yy=Math.max(g.top+6*u,Math.min(g.bottom-6*u,l.y+dy));c.strokeText(text,right,yy);c.fillText(text,right,yy);}
  m.endGainLabels.push({...l,left,right,top,bottom,center:l.y,horizontal:true});
 }
 c.restore();
}
// Observation coverage is a display-only mask. Never synthesize zero, carry a
// missing weekly histogram into the next week, or feed this mask to an engine.
// The price calendar defines the visible cells; weekends add no daily cells.
// H4 cash context refers to the preceding completed weekday (UTC).
function observationGaps(calendar, groups, weekly=false, h4=false){
 const day=86400000,bucket=d=>{let t=Date.parse(d.slice(0,10)+'T00:00:00Z');if(weekly)t-=((new Date(t).getUTCDay()+6)%7)*day;return t;};
 const known=groups.map(points=>new Set(points.filter(p=>Number.isFinite(p.v)).map(p=>bucket(p.date))));
 const out=[];let gap=null;
 for(const d of calendar){let ref=d;
  if(h4){let t=Date.parse(d.slice(0,10)+'T00:00:00Z')-day;while([0,6].includes(new Date(t).getUTCDay()))t-=day;ref=new Date(t).toISOString();}
  const absent=known.some(set=>!set.has(bucket(ref)));
  if(absent){if(gap)gap.to=d;else{gap={from:d,to:d};out.push(gap);}}else gap=null;
 }return out;
}
function drawObservationGaps(c,m,g,x,index,publicView=false){
 m.missingLayout=[];const u=1/(g.uiScale||1);
 c.save();c.beginPath();c.rect(g.left,g.top,g.right-g.left,g.bottom-g.top);c.clip();
 for(const gap of m.missing||[]){const a=index(gap.from),b=index(gap.to),left=Math.max(g.left,x(a-.5)),right=Math.min(g.right,x(b+.5));if(right<=left)continue;
  c.fillStyle='rgba(123,137,151,.18)';c.fillRect(left,g.top,right-left,g.bottom-g.top);
  c.strokeStyle='rgba(104,119,134,.22)';c.lineWidth=.7*u;c.setLineDash([]);
  c.save();c.beginPath();c.rect(left,g.top,right-left,g.bottom-g.top);c.clip();
  for(let q=left-(g.bottom-g.top);q<right;q+=12*u){c.beginPath();c.moveTo(q,g.bottom);c.lineTo(q+g.bottom-g.top,g.top);c.stroke();}c.restore();
  const label=publicView?'N/D':'Donnée absente';c.font=(g.uiScale<1?'700 '+Math.max(11,10*u):'400 10')+'px Segoe UI,Arial,sans-serif';c.fillStyle='#52677c';c.textAlign='center';c.textBaseline='top';
  if(right-left>c.measureText(label).width+8*u)c.fillText(label,(left+right)/2,g.top+5*u);
  else if(right-left>=10*u)c.fillText('—',(left+right)/2,g.top+5*u);
  m.missingLayout.push({...gap,left,right,top:g.top,bottom:g.bottom});
 }c.restore();
}
// Same S&P framing and snug value tags on PC, browser and phone. Inset phone
// labels stay inside the plot; only the measured digits receive a light box.
// Screen-space connector preference, after every text/curve constraint.
// Proper intersections only: two labels may legitimately share an anchor.
// Bound the search to 32 valid slots so dense histories stay responsive.
function leaderCrossings(line,leaders=[]){
 const turn=(a,b,c)=>(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);
 const a={x:line.x1,y:line.y1},b={x:line.x2,y:line.y2};
 return leaders.reduce((n,l)=>{const c={x:l.x1,y:l.y1},d={x:l.x2,y:l.y2};return n+(turn(a,b,c)*turn(a,b,d)<-1e-6&&turn(c,d,a)*turn(c,d,b)<-1e-6?1:0);},0);
}
function labelLeader(box,px,py,radial=false){
 const x=(box.left+box.right)/2,y=(box.top+box.bottom)/2;
 if(!radial)return {x1:x,y1:y<py?box.bottom:box.top,x2:px,y2:py};
 const dx=px-x,dy=py-y,t=1/Math.max(Math.abs(dx)/((box.right-box.left)/2+3),Math.abs(dy)/((box.bottom-box.top)/2+3),1);
 return {x1:x+dx*t,y1:y+dy*t,x2:px,y2:py};
}
function chooseLeaderSlot(slots,fits,connector,leaders=[]){
 let best=null,crossings=Infinity,valid=0;
 for(const box of slots){if(!fits(box))continue;const n=leaderCrossings(connector(box),leaders);if(n<crossings){best=box;crossings=n;}if(n===0||++valid>=32)break;}
 return best;
}
function drawValuationLevels(c,m,g,values){
 const u=1/(g.uiScale||1);m.valuationLabelLayout=[];
 c.save();c.font='700 '+Math.max(g.uiScale<1?11:10,10*u)+'px Segoe UI,Arial,sans-serif';c.textBaseline='middle';c.globalAlpha=1;
 for(const v of values){
  if(!Number.isFinite(v.v)||!Number.isFinite(v.py)||v.py<g.top||v.py>g.bottom)continue;
  const label=v.v.toLocaleString('fr-FR',{maximumFractionDigits:0}),width=Math.ceil(c.measureText(label).width)+4*u,left=g.insetAxes?g.right-width-8*u:g.right+8*u;
  // Exact levels take priority over rounded grid captions (07/11 request).
  // The snug light backing may cover a tick, but never shift the value or add
  // an oblique leader. One implementation serves all three timeframes/readers.
  c.fillStyle='#f7f9fc';c.fillRect(left,v.py-8*u,width,16*u);c.fillStyle=v.color;c.textAlign='left';c.fillText(label,left+2*u,v.py);
  m.valuationLabelLayout.push({key:v.key,value:v.v,text:label,color:v.color,levelY:v.py,left,right:left+width,top:v.py-8*u,bottom:v.py+8*u});
 }c.restore();
}
/** Calendar price return, display only. Cash uses daily observations even in
 * weekly view: a week crossing January must not move the year-end reference.
 * H4 uses its own quoted series. Missing prior-year data is not a zero return. */
function yearToDate(rows){
 const last=rows.at(-1);if(!last||!Number.isFinite(last.close)||last.close<=0)return null;
 const year=last.date.slice(0,4),base=rows.findLast(r=>r.date<year+'-01-01'&&Number.isFinite(r.close)&&r.close>0);
 return {year:Number(year),asOf:last.date,percent:base?100*(last.close/base.close-1):null};
}
/** Fixed, small price-chart overlay. It describes the latest loaded year,
 * independently of panning, hover and the capital's zoom-relative return. */
// Display graduations only. Nice linear steps preserve a labelled zero; a
// semi-logarithmic axis selects rounded levels in value space, never rounded
// pixel positions. Neither the domain nor the financial observations change.
// Stable toolbar slots, different calendar spans only in H4. No bar-count
// approximation: month subtraction clamps the day at the end of the month.
// Device distinction only for the entry preset: resizing a PC window must not
// turn its requested three-month H4 entry into the phone's one-month entry.
function phoneDevice(){return typeof navigator!=='undefined'&&/iPhone|iPod|Android.*Mobile/i.test(navigator.userAgent||'');}
function periodOption(value,h4,phone=phoneDevice()){
 const explicit=/^months:(\d+)$/.exec(String(value));
 const months=explicit?Number(explicit[1]):!h4&&phone?({'1':6,'5':12,'10':36}[value]):h4?{ytd:1,'1':3,'3':6,'5':12,'10':24}[value]:null;
 return months?{key:'months:'+months,label:({12:'1 an',24:'2 ans',36:'3 ans'}[months]||(phone?months+'m':months+' mois')),months}:{key:String(value),label:value==='all'?'Tout':value==='ytd'?'YTD':value==='1'?'1 an':value+' ans'};
}
// Timeframe entry defaults belong to the display only, not engine settings.
function entryPeriod(previous,next,phone=phoneDevice()){
 if(previous===next)return null;
 if(next==='h4')return phone?'ytd':1;
 if(phone)return next==='daily'?'months:6':'months:36';
 return previous==='h4'?(next==='daily'?5:10):null;
}
function monthsBefore(day,months){
 const d=new Date(day.slice(0,10)+'T12:00:00Z'),n=d.getUTCDate();d.setUTCDate(1);d.setUTCMonth(d.getUTCMonth()-months);
 const last=new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth()+1,0)).getUTCDate();d.setUTCDate(Math.min(n,last));return d.toISOString().slice(0,10);
}
function roundTicks(lo,hi,count=5,log=false,anchors=[]){
 if(!Number.isFinite(lo)||!Number.isFinite(hi)||!(hi>lo))return [];
 let values=[];
 if(log&&lo>0&&hi/lo>8){
  const a=Math.log(lo),b=Math.log(hi),candidates=[];
  for(let e=Math.floor(Math.log10(lo));e<=Math.ceil(Math.log10(hi));e++)for(const n of [1,2,5]){const v=n*10**e;if(v>=lo&&v<=hi)candidates.push(v);}
  for(let i=0;i<count;i++){const t=a+(b-a)*i/(count-1),v=candidates.reduce((best,v)=>best===null||Math.abs(Math.log(v)-t)<Math.abs(Math.log(best)-t)?v:best,null);if(v!==null)values.push(v);}
 }else{
  const raw=(hi-lo)/Math.max(1,count-1),power=10**Math.floor(Math.log10(raw)),step=[1,2,2.5,5,10].map(n=>n*power).reduce((best,v)=>Math.abs(Math.log(v/raw))<Math.abs(Math.log(best/raw))?v:best,power);
  for(let i=Math.ceil(lo/step-1e-10);i<=Math.floor(hi/step+1e-10);i++)values.push(Number((i*step).toPrecision(12)));
 }
 for(const v of anchors)if(v>=lo&&v<=hi)values.push(v);
 return [...new Set(values)].sort((a,b)=>a-b);
}
function textBoxesOverlap(a,b,gap=3){return a.left<b.right+gap&&a.right>b.left-gap&&a.top<b.bottom+gap&&a.bottom>b.top-gap;}
// Remember the physical footprint of inset tick labels before placing DD,
// YTD, endpoint returns or cards. Prices and symbols may pass through ticks.
// Base caption is reserved before annotations and repainted last so curves,
// hover guides and performance labels cannot obscure it. An off-screen H4
// base is explicitly indicated by an arrow instead of inventing a grid level.
function equityBaseLabel(c,m,g,lineY,paintOnly=false){
 const u=1/(g.uiScale||1);
 if(!paintOnly){
  if(!Number.isFinite(lineY)){m.equityBaseLabelBounds=null;return;}
  const text='100',left=g.left+8*u,top=Math.max(g.top+2*u,Math.min(g.bottom-16*u,lineY-17*u));
  c.save();c.font=10*u+'px Segoe UI,Arial,sans-serif';const width=c.measureText(text).width+6*u;c.restore();
  m.equityBaseLabelBounds={left,right:left+width,top,bottom:top+16*u,width,height:16*u,text,lineY,plain:true};
  return; // reserve only: paint once after all curves and hover layers
 }
 const b=m.equityBaseLabelBounds;if(!b)return;
 c.save();c.font=10*u+'px Segoe UI,Arial,sans-serif';c.textAlign='left';c.textBaseline='middle';
 c.strokeStyle='rgba(255,255,255,.86)';c.lineWidth=4*u;c.strokeText('100',b.left,b.top+8*u);c.fillStyle='#52677c';c.fillText('100',b.left,b.top+8*u);c.restore();
}
function axisText(c,m,g,text,x,y,align,extra={}){
 c.save();c.textAlign=align;c.textBaseline='alphabetic';
 const width=c.measureText(text).width,u=1/(g.uiScale||1),left=align==='right'?x-width:align==='center'?x-width/2:x;
 const box={left,right:left+width,top:y-11*u,bottom:y+3*u,...extra};
 c.fillText(text,x,y);c.restore();(m.axisTextBoxes||(m.axisTextBoxes=[])).push(box);return box;
}
// The photo control is fixed at top:10/right:12, 30x30 CSS pixels. Reserve
// its footprint (+8px gap) in canvas coordinates, including private UI scaling.
// Keep this consistent with .chart-share in the private/public stylesheets.
function chartActionRight(g,top,bottom,right=g.right){
 const u=1/(g.uiScale||1);
 return top<44*u&&bottom>6*u?Math.min(right,g.w-50*u):right;
}
function drawYtd(c,m,g,measureOnly=false){
 m.ytdLayout=null;if(m.kind!=='price'||!m.ytd)return;
 const p=m.ytd.percent,label='YTD '+(Number.isFinite(p)?(p>=0?'+':'')+p.toLocaleString('fr-FR',{minimumFractionDigits:2,maximumFractionDigits:2})+' %':'—');
 const u=1/(g.uiScale||1);c.save();c.font='400 '+(g.insetAxes?9:10)*u+'px Segoe UI,Arial,sans-serif';
 const w=c.measureText(label).width+8*u,h=16*u,top=g.top+5*u;let right=chartActionRight(g,top,top+h,g.right-6*u);
 if(g.insetAxes)for(const b of (m.axisTextBoxes||[]).slice().sort((a,b)=>b.right-a.right))if(textBoxesOverlap({left:right-w,right,top,bottom:top+h},b,4*u))right=Math.min(right,b.left-5*u);
 if(!measureOnly){c.fillStyle='rgba(255,255,255,.72)';c.fillRect(right-w,top,w,h);c.fillStyle='#5b6f82';c.textAlign='right';c.textBaseline='middle';c.fillText(label,right-4*u,top+h/2);}c.restore();
 m.ytdLayout={label,percent:p,left:right-w,right,top,bottom:top+h};
}
/** Viewport-only LQQ alignment; raw accounts and episode statistics stay intact.
 * Reanchor only the episode already underway at the leftmost LVR2 observation.
 * Later episodes keep their original BUY anchor. Explicit spans distinguish a
 * missing quote from a position exit; 50 -> 100% never starts a new span.
 * Return raw-coordinate values so curve, axis extent, hover and collision
 * geometry all use exactly the same projection before the shared LVR2 /100.
 */
function referenceWindow(reference,sys2,from){
 if(!reference)return null;
 const span=reference.spans?.find(([a,b])=>a<from&&from<=b);
 if(!span)return reference;
 const values=new Map(sys2.map(p=>[p.date,p.v]));
 const anchor=reference.points.find(p=>p.date>=from&&p.date<=span[1]&&p.v>0&&values.get(p.date)>0);
 if(!anchor)return reference;
 const factor=values.get(anchor.date)/anchor.v;
 return {...reference,points:reference.points.map(p=>p.date>=span[0]&&p.date<=span[1]&&p.v>0?{...p,v:p.v*factor}:p)};
}
/** Other real ETF overlays use the same projection as LQQ, on their parent
 * strategy's axis. Cache only geometry; never mutate the source account. */
function prepareReferences(m){
 for(const r of m.references||[]){const source=m.series[r.axis].points,from=m.equityBases[r.axis]?.date;
  if(r.cache?.from!==from||r.cache?.source!==source){const projected=referenceWindow(r,source,from);r.window={points:projected.points,color:r.color};r.cache={from,source};}
 }
}
function activeReferences(m,hidden){return (m.references||[]).filter(r=>!hidden.has(r.toggle)&&!hidden.has(r.parent));}
/** Already computed observations only. Use LVR2's exact axis and rebasing,
 * and break the path at every missing/flat/short point. No extra capital stats. */
function drawReference(c,m,g,x,y,start,end){
 m.lqqDrawn=[];if(!m.lqq||typeof y!=='function')return;
 c.save();c.beginPath();c.rect(g.left,g.top,g.right-g.left,g.bottom-g.top);c.clip();
 c.strokeStyle=m.lqq.color;c.lineWidth=1.8;c.setLineDash([5,3]);c.beginPath();let previous=null,last=null;
 for(const p of (m.lqqWindow||m.lqq).points){const i=p.idx??p.i;
  if(i<start-1||i>end+1||!(p.v>0)){previous=null;continue;}
  const xx=x(i),yy=y(p.v);if(previous)c.lineTo(xx,yy);else c.moveTo(xx,yy);
  previous=p;if(i>=start&&i<=end){last={date:p.date,x:xx,y:yy,value:p.v};m.lqqDrawn.push(last);}
 }c.stroke();c.setLineDash([]);
 if(last){c.fillStyle=m.lqq.color;c.beginPath();c.arc(last.x,last.y,2.5,0,Math.PI*2);c.fill();}
 c.restore();
}
/** H4 presentation only: supplied activated corridors stay crisp at the plot
 * edge. The short horizontal bridge repeats the last observed threshold; it
 * never projects a new trading level into a fictitious future candle. */
function h4LevelColor(color,ready){return ready?(color==='#198561'?'#125d44':'#842e42'):'#65717d';}
// Screen-space H4 aids only: 20 actual bar intervals ending at the last candle,
// never a forecast or an order. Shared by private and public renderers.
function h4TriggerGuide(g,right,py,step,color){
 return {left:Math.max(g.left,right-20*Math.abs(step)),right,y:py,below:color!=='#198561'};
}
function placeH4TriggerCard(g,guide,w,h,blocked,preferred=null){
 if(preferred)return preferred; // Keep annotations attached while dragging.
 const min=g.left+w/2+4,max=g.right-w/2-4;if(min>max)return null;
 const center=Math.max(min,Math.min(max,(guide.left+guide.right)/2));
 const xs=[center,Math.max(min,Math.min(max,guide.right-w/2-12)),Math.max(min,Math.min(max,guide.left+w/2))];
 for(let gap=10;gap<g.bottom-g.top;gap+=6)for(const x of xs){
  const top=guide.below?guide.y+gap:guide.y-gap-h;
  const box={left:x-w/2,right:x+w/2,top,bottom:top+h};
  if(box.top<g.top+3||box.bottom>g.bottom-3||blocked(box))continue;
  return box;
 }
 return null;
}
function drawActivatedLevels(c,m,g,lines,y){
 m.activatedLevelLayout=[];
 for(const line of lines){
  const {left,right,lower,upper,level,color,id}=line;
  if(right<g.left||left>g.right||right<=left)continue;
  c.save();c.beginPath();c.rect(g.left,g.top,g.right-g.left,g.bottom-g.top);c.clip();
  c.strokeStyle=color;c.globalAlpha=1;c.lineWidth=1.5;c.setLineDash([7,4]);
  for(const values of [lower,upper]){c.beginPath();c.moveTo(left,y(values[0]));c.lineTo(right,y(values[1]));if(right<=g.right)c.lineTo(g.right,y(values[1]));c.stroke();}c.restore();
  // Keep the visible part of the 20-bar guide during a pan. Its arrow follows
  // the true last candle and clips naturally; only the margin badge requires
  // that candle on screen. Never snap an offscreen trigger to the plot edge.
  const py=y(level);if(py<g.top||py>g.bottom)continue;
  const guide=h4TriggerGuide(g,right,py,line.barStep||0,color);
  c.save();c.beginPath();c.rect(g.left,g.top,g.right-g.left,g.bottom-g.top);c.clip();
  c.strokeStyle=color;c.fillStyle=color;c.globalAlpha=.85;c.lineWidth=1;c.setLineDash([2,3]);
  c.beginPath();c.moveTo(guide.left,py);c.lineTo(right,py);c.stroke();
  const arrowHeight=2*(line.arrowHeight||11),ax=right-(g.insetAxes?12/(g.uiScale||1):6),ay=py+(guide.below?arrowHeight:-arrowHeight);c.setLineDash([]);c.beginPath();c.moveTo(ax,py);c.lineTo(ax,ay);c.stroke();
  c.beginPath();c.moveTo(ax,ay);c.lineTo(ax-3.5,ay+(guide.below?-4:4));c.lineTo(ax+3.5,ay+(guide.below?-4:4));c.closePath();c.fill();c.restore();
  if(right>g.right+.5)continue;
  c.save();c.globalAlpha=1;c.setLineDash([]);c.font='600 10px Segoe UI,Arial,sans-serif';
  const text=Number(level).toLocaleString('fr-FR',{maximumFractionDigits:0}),w=c.measureText(text).width+10,h=19;
  const inside=g.insetAxes||g.w-g.right<w+4,x=inside?g.right-w:g.right+2;
  // The adapter supplies only the evaluated display tone, never a new rule.
  c.fillStyle=line.levelColor||'#65717d';c.fillRect(x,py-h/2,w,h);c.fillStyle='#fff';c.textAlign='center';c.textBaseline='middle';c.fillText(text,x+w/2,py);
    c.restore();const box={id,level,text,x,y:py-h/2,w,h,edge:g.right,guide,arrowHeight};m.activatedLevelLayout.push(box);
  if(m.annotationRects)m.annotationRects.push(box);
 }
}
return {drawRiskLegendLine,drawEquitySymbols,drawH4Extremes,compactPerformanceCard,drawCompactPerformanceCard,h4TriggerGuide,placeH4TriggerCard,drawActivatedLevels,prepareReferences,activeReferences,observationGaps,drawObservationGaps,drawValuationLevels,windowStats,periodValues,drawPeriods,h4PeriodValues,h4WindowStats,drawH4Card,cursorDrawdown,drawH4Periods,drawEndGains,yearToDate,drawYtd,referenceWindow,drawReference,roundTicks,axisText,equityBaseLabel,entryPeriod,chartActionRight,textBoxesOverlap,phoneDevice,periodOption,monthsBefore,leaderCrossings,labelLeader,chooseLeaderSlot};})();
// Public shortcut: no notice below Capital, unlike the fully documented PC.
// Its top cannot always reach the sticky header before the page ends. Compare
// against the reachable scroll destination, not an unreachable viewport edge.
(()=>{
 if(typeof document==='undefined'||!document.body)return;
 function mount(){
  const charts=document.getElementById('charts');if(!charts)return;
  const nav=document.createElement('nav'),button=document.createElement('button');
  nav.id='chart-shortcuts';nav.setAttribute('aria-label','Accès rapide aux graphiques');
  button.id='chart-return';button.type='button';nav.append(button);document.body.append(nav);
  let target=null,frame=0;
  const desktop=matchMedia('(min-width:761px)');
  const offset=()=>Math.max(0,document.querySelector(desktop.matches?'.site-controls':'#mobile-navigation')?.getBoundingClientRect().bottom||0)+12;
  const destination=element=>{
   const end=Math.max(0,document.documentElement.scrollHeight-innerHeight);
   // On mobile the blue header scrolls away above .quick. Its current bottom
   // is not a stable offset: the first tap used to stop short of Capital.
   // Capital is the last panel: target page end, also used by update() below.
   if(!desktop.matches&&element===charts.querySelector('[data-panel="equity"]'))return end;
   return Math.min(end,Math.max(0,scrollY+element.getBoundingClientRect().top-offset()));
  };
  function update(){
   frame=0;
   // Index/timeframe changes replace the panels: always resolve current nodes.
   const price=charts.querySelector('.panel.price'),capital=charts.querySelector('[data-panel="equity"]');
   if(!price||!capital){target=null;nav.hidden=true;return;}
   const atCapital=scrollY>=destination(capital)-24;
   target=atCapital?price:capital;nav.hidden=false;
   const index=document.getElementById('index')?.selectedOptions[0]?.textContent||'Cours';
   const label=atCapital?(index==='Nasdaq 100'?'Nasdaq':index):'Capital';
   button.textContent=(atCapital?'↑ ':'↓ ')+label;
   button.title='Aller à · '+label;button.setAttribute('aria-label',button.title);
  }
  const schedule=()=>{if(!frame)frame=requestAnimationFrame(update);};
  addEventListener('scroll',schedule,{passive:true});addEventListener('resize',schedule);
  new MutationObserver(schedule).observe(charts,{childList:true});
  button.addEventListener('click',()=>{if(target)scrollTo({top:destination(target),behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});});
  update();
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount,{once:true});else mount();
})();
// End public shortcut.
// Public gesture help: display-only text, never private rules or model fields.
// One delegated mouse tooltip survives panel replacement; touch remains clear.
(()=>{
 if(!document.body)return; // Calculation-only test DOM.
 function mount(){
  const charts=document.getElementById('charts');if(!charts)return;
  const help=document.createElement('div');help.id='chart-gesture-help';help.hidden=true;
  help.setAttribute('role','tooltip');document.body.append(help);let timer=0;
  const hide=()=>{clearTimeout(timer);help.hidden=true;};
  function queue(event){
   hide();const canvas=event.target.closest?.('canvas[data-chart-help]');
   if(!canvas||event.buttons||event.pointerType==='touch')return;
   const {clientX:x,clientY:y}=event;
   timer=setTimeout(()=>{
    if(!canvas.isConnected)return;
    help.replaceChildren(...canvas.dataset.chartHelp.split('\n').map(text=>{
     const line=document.createElement('div'),colon=text.indexOf(':');
     if(colon<0)line.textContent=text;
     else{const label=document.createElement('strong');label.textContent=text.slice(0,colon+1);line.append(label,document.createTextNode(text.slice(colon+1)));}
     return line;
    }));help.hidden=false;
    help.style.left=Math.max(8,Math.min(x+16,innerWidth-help.offsetWidth-8))+'px';
    help.style.top=Math.max(8,Math.min(y+18,innerHeight-help.offsetHeight-8))+'px';
   },900);
  }
  for(const name of ['pointermove','pointerup'])charts.addEventListener(name,queue,{passive:true});
  for(const name of ['pointerdown','pointerleave','pointercancel','wheel'])charts.addEventListener(name,hide,{passive:true});
  for(const name of ['scroll','resize','blur','keydown'])addEventListener(name,hide,{passive:true});
  new MutationObserver(hide).observe(charts,{childList:true});
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount,{once:true});else mount();
})();
// End public gesture help.
/** Public display-only reader. Its inputs are already-computed curves, labels
 * and drawing geometry. No calls to a financial engine or external data API. */
// Canvas font lists must match viewer.css, including Arial/sans-serif fallback:
// iPhone has no Segoe UI. A single-family font can silently fall back to serif.
(()=>{
const $=id=>document.getElementById(id),N=AWW_VIEW_NAV,F=new Intl.NumberFormat('fr-FR',{maximumFractionDigits:2}),compact=()=>innerWidth<=760;
const fmt=(x,d=2)=>Number.isFinite(x)?x.toLocaleString('fr-FR',{maximumFractionDigits:d}):'—',date=s=>s?s.slice(8,10)+'/'+s.slice(5,7)+'/'+s.slice(0,4)+(s.length>10?' '+s.slice(11,16)+' UTC':''):'—';
// Month names only in cursor labels; ISO dates and data navigation are unchanged.
const cursorDateFormat=new Intl.DateTimeFormat('fr-FR',{day:'numeric',month:'long',year:'numeric',timeZone:'UTC'});
const cursorWeekdayFormat=new Intl.DateTimeFormat('fr-FR',{weekday:'long',timeZone:'UTC'});
const cursorDate=(d,weekday=false)=>{if(!d)return '—';const day=new Date(d.slice(0,10)+'T00:00:00Z'),hour=d.length>10?' '+Number(d.slice(11,13))+'h'+(d.slice(14,16)==='00'?'':d.slice(14,16))+' UTC':'';return (weekday?cursorWeekdayFormat.format(day)+' ':'')+cursorDateFormat.format(day)+hour;};
const state={cashSystem:'sys2',catalog:null,view:null,dates:[],times:[],panels:[],start:0,count:80,hover:null,cursor:null,raf:0,request:0,log:false};
const cache=new Map(),pointers=new Map();let gesture=null,observer=null;
// Display-only session history: ten actions plus the current view. Store tiny
// geometry snapshots, never panel data, signals or cursor movements. A gesture
// (pan, pinch, axis drag, navigator, wheel burst) commits once on release.
const viewHistory={context:'',items:[],index:-1,interaction:null,timer:null,restoring:false};
function rememberView(){
 if(!state.view||!state.dates.length)return;
 const h=viewHistory,context=[state.view.index,state.view.tf,state.view.calendar].join('|');
 const item={start:state.start,count:state.count,scales:state.panels.map(m=>[m.id,m.yZoom||1]),preset:state.periodPreset??null};
 item.key=JSON.stringify([item.start,item.count,item.scales]);
 if(h.context!==context){clearTimeout(h.timer);Object.assign(h,{context,items:[item],index:0,interaction:null,timer:null});}
 else if(!h.restoring&&!h.interaction){
  if(h.items[h.index]?.key===item.key)h.items[h.index]=item;
  else{h.items=h.items.slice(0,h.index+1);h.items.push(item);if(h.items.length>11)h.items.shift();h.index=h.items.length-1;}
 }
 $('view-back').disabled=h.index<=0;$('view-forward').disabled=h.index>=h.items.length-1;
}
function beginViewAction(kind){if(viewHistory.interaction===kind)return;endViewAction();rememberView();viewHistory.interaction=kind;}
function endViewAction(){clearTimeout(viewHistory.timer);viewHistory.timer=null;if(viewHistory.interaction){viewHistory.interaction=null;rememberView();}}
function moveViewHistory(direction){
 endViewAction();rememberView();const h=viewHistory,next=h.index+direction;if(next<0||next>=h.items.length)return;
 const item=h.items[next];h.index=next;h.restoring=true;
 try{
  state.start=item.start;state.count=item.count;state.hover=null;state.cursor=null;
  const scales=new Map(item.scales);for(const m of state.panels){m.yZoom=scales.get(m.id)||1;delete m.sliderMarkers;}
  setPeriodPreset(item.preset);sync(true);
 }finally{h.restoring=false;}
}
async function json(url){const r=await fetch(url,{cache:url==='catalog.json'?'no-cache':'default'});if(!r.ok)throw Error('Fichier indisponible ('+r.status+') : '+url);const raw=await r.text();
 if(url.startsWith('data/')){const digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(raw));const hex=Array.from(new Uint8Array(digest),x=>x.toString(16).padStart(2,'0')).join('');if(url!=='data/'+hex+'.json')throw Error('Données incomplètes : rechargez la page.');}
 return JSON.parse(raw);
}
async function chunk(url){if(!/^data\/[a-f0-9]{64}\.json$/.test(url))throw Error('Chemin de données invalide');if(!cache.has(url)){if(cache.size>45)cache.clear();cache.set(url,json(url).catch(e=>{cache.delete(url);throw e;}));}return cache.get(url);}
// Public labels stay neutral at EVERY width; private wording belongs on NAS.
function bothDirectionText(){return 'V+R';}
function syncDirectionText(){for(const id of ['scenario','chart-direction']){const o=$(id)?.querySelector('option[value="vr"]');if(o)o.textContent=bothDirectionText();}}
function scenarios(){
 const h4=$('unit').value==='h4',old=$('scenario').value,items=h4?[['v','V'],['r','R'],['vr',bothDirectionText()]]:[['sys1','LVR1'],['classic','LVR2']];
 $('scenario-control').hidden=!h4;$('scenario').replaceChildren(...items.map(([value,text])=>new Option(text,value)));
 if(h4)$('scenario').value=items.some(x=>x[0]===old)?old:'vr';
 if(!h4)$('scenario').value=state.cashSystem==='sys2'?'classic':'sys1';
 for(const [id,key] of [['system-1','sys1'],['system-2','sys2']]){const b=$(id);b.disabled=h4;b.classList.toggle('active',state.cashSystem===key);b.setAttribute('aria-pressed',String(state.cashSystem===key));}
}
function setSystem(system){if($('unit').value==='h4')return;state.cashSystem=system;scenarios();return loadView();}
function setStatus(text){$('status').textContent=text;}
async function loadView(initial=false,periodYears=null,followWeekly=false){
 endViewAction();
 if(initial&&!state.periodPreset&&AWW_ANNUAL_VIEW.phoneDevice())periodYears=AWW_ANNUAL_VIEW.entryPeriod(null,$('unit').value);
 syncViewButtons();
 const request=++state.request,oldFrom=state.dates[Math.floor(state.start)]?.slice(0,10),oldTo=state.dates[Math.min(state.dates.length-1,Math.ceil(state.start+state.count)-1)]?.slice(0,10);
 // When following the newest prices, keep following them across timeframes:
 // an intraday snapshot can be newer than the last imported cash session. A user
 // inspecting the past keeps the historical window instead.
 const followLatest=state.dates.length>0&&state.start+state.count>=state.dates.length-1e-6;
 const v=state.catalog.views.find(v=>v.index===$('index').value&&v.tf===$('unit').value&&v.scenario===$('scenario').value);if(!v)return;
 setStatus('Chargement des résultats précalculés…');$('charts').classList.add('loading');
 try{
  const [dates,...panels]=await Promise.all([chunk(v.calendar),...v.panels.map(chunk)]);if(request!==state.request)return;
  if(v.tf==='h4'&&(initial||followWeekly)){
   const regime=panels.find(p=>p.kind==='price')?.regimes?.[0]?.position;
   const direction=Number.isFinite(regime)?regime>0?'v':regime<0?'r':'vr':v.scenario;
   if(direction!==v.scenario){$('scenario').value=direction;return loadView(initial,periodYears,followWeekly);}
  }
  // H4 creates only its three panels; no hidden DOM/canvases. Existing shared
  // history chunks and daily/weekly views remain compatible with older exports.
  const sameCalendar=state.view?.index===v.index&&state.view?.tf===v.tf&&state.view?.calendar===v.calendar;
  const retained=sameCalendar?{start:state.start,count:state.count,scales:new Map(state.panels.map(m=>[m.id,m.yZoom||1]))}:null;
  state.view=v;if(!AWW_ANNUAL_VIEW.phoneDevice()&&state.periodPreset&&state.periodPreset!=='all'&&!calendarBounds()&&(state.periodPreset.startsWith('months:')!==(v.tf==='h4')))setPeriodPreset();state.dates=dates;state.times=dates.map(Date.parse);state.panels=panels.filter(p=>v.tf!=='h4'||p.kind==='price'||p.id==='position'||p.id==='equity').map(p=>({...p,references:p.references?.map(r=>({...r,points:r.points.map(([date,v])=>({date,v,i:N.position(state.times,Date.parse(date))}))})),...(p.lqq?{lqq:{...p.lqq,points:p.lqq.points.map(([date,v])=>({date,v,i:N.position(state.times,Date.parse(date))}))}}:{}),missing:['ad','net','hl','valuation'].includes(p.id)?AWW_ANNUAL_VIEW.observationGaps(dates,p.series.filter(s=>s.axis!=='secondary').map(s=>s.points.map(([date,v])=>({date,v}))),p.id==='hl',v.tf==='h4'):[],yZoom:retained?.scales.get(p.id)||1,...(p.capitalPeriods?{capitalPeriods:p.capitalPeriods[v.scenario==='sys1'?'sys1':'sys2'],periodSystemIndex:v.scenario==='sys1'?0:1}:{}),series:p.series.map(s=>({...s,points:s.points.filter(r=>r[0]>=dates[0].slice(0,10)&&r[0]<=dates.at(-1)+'\uffff').map(([d,v])=>({date:d,v,i:N.position(state.times,Date.parse(d))}))})),candles:p.candles?.map(r=>({date:r[0],open:r[1],high:r[2],low:r[3],close:r[4],provisional:r[5],boost:r[6],estimated:!!r[7],i:N.position(state.times,Date.parse(r[0]))})),visible:true}));
  for(const m of state.panels){for(const s of m.series){s.indices=s.points.map(p=>p.i);s.dates=s.points.map(p=>p.date);}m.candleDates=m.candles?.map(r=>r.date);m.dcaDates=m.dca?.map(r=>r[0]);m.drawdownDates=m.drawdownSeries?.map(r=>r[0]);}
  state.hover=null;gesture=null;pointers.clear();
  let range=retained||(!initial&&oldFrom?N.windowFor(dates,oldFrom,followLatest?v.to.slice(0,10):oldTo):null);if(!range)range=compact()?{start:Math.max(0,dates.length-80),count:Math.min(80,dates.length)}:N.windowFor(dates,(+v.to.slice(0,4)-3)+v.to.slice(4,10),v.to.slice(0,10));
  let bounds=calendarBounds();const ytd=state.periodPreset==='ytd';
  if(bounds){
   // H4 may start decades later than cash. Clamp the requested years to its
   // coverage, or drop a disjoint selection rather than displaying stale years.
   bounds=[String(Math.max(+bounds[0],+dates[0].slice(0,4))),String(Math.min(+bounds[1],+dates.at(-1).slice(0,4)))];
   setPeriodPreset(bounds[0]<=bounds[1]?'calendar:'+bounds.join(':'):null);bounds=calendarBounds();
  }
  if(bounds||ytd){const selected=bounds?N.calendarYears(dates,...bounds):N.sinceYear(dates,dates.at(-1).slice(0,4));if(selected)range=selected;else setPeriodPreset();}
  if(periodYears!==null){
   const option=AWW_ANNUAL_VIEW.periodOption(periodYears,v.tf==='h4');
   range=N.windowFor(dates,option.months?AWW_ANNUAL_VIEW.monthsBefore(v.to,option.months):(+v.to.slice(0,4)-Number(periodYears))+v.to.slice(4,10),v.to.slice(0,10));
   setPeriodPreset(option.key);
  }
  Object.assign(state,N.clamp(range?.start||0,range?.count||dates.length,dates.length,calendarBounds()||ytd?1:5));
  const shortDate=value=>String(value).slice(0,10).split('-').reverse().join('/');
  $('coverage').textContent=shortDate(v.from)+' → '+shortDate(v.to)+' · '+fmt(v.bars)+' bougies · export du '+shortDate(state.catalog.generatedAt);
  for(const id of ['from','to']){$(id).min=v.from.slice(0,4)+'-01-01';$(id).max=v.to.slice(0,4)+'-12-31';}
  const years=[...new Set(dates.map(d=>d.slice(0,4)))].reverse();
  $('since-year').replaceChildren(new Option('Année',''),...years.map(y=>new Option(y,y)));
  $('end-year').replaceChildren(new Option('Année',''),...years.map(y=>new Option(y,y)));
  updatePeriodControls();createPanels();sync(true);setStatus('');
 }catch(e){if(request===state.request)setStatus('Impossible de charger cette vue. '+e.message);}
 finally{if(request===state.request)$('charts').classList.remove('loading');}
}
function textNode(tag,text,cls){const e=document.createElement(tag);e.textContent=text;if(cls)e.className=cls;return e;}
function createPanels(){
 observer?.disconnect();$('charts').replaceChildren();
 $('charts').dataset.timeframe=state.view.tf; // Layout only; no extra field in public financial data.
 for(const m of state.panels){
  const article=document.createElement('article');article.className='panel '+(m.kind==='price'?'price':m.performance?'equity-comparison':m.id);if(m.performance){const header=textNode('div','','equity-head');header.append(textNode('h2','Capital'),equityControls(m));article.append(header);}else article.append(textNode('h2',m.title));
  article.dataset.panel=m.id;
  if(m.kind==='price'){m.riskTitle=textNode('span','','price-title-risk');m.ddTitle=textNode('span','','price-title-dd');article.querySelector('h2').append(m.riskTitle,m.ddTitle);}
  if(m.regimes){
   const bar=textNode('div','','prophet-chart-tools'),label=textNode('label','','prophet-direction-control'),select=document.createElement('select');select.id='chart-direction';select.setAttribute('aria-label','Filtre du graphique');
   label.append(textNode('span','Filtre','h4-direction-caption'));
   for(const [value,text] of [['v','V'],['r','R'],['vr',bothDirectionText()]])select.append(new Option(text,value));select.value=state.view.scenario;select.onchange=()=>{$('scenario').value=select.value;return loadView();};label.append(select);bar.append(label);const choices=textNode('div','','h4-direction-choices');choices.setAttribute('role','radiogroup');choices.setAttribute('aria-label','Filtre');for(const [value,caption] of [['v','V'],['r','R'],['vr','V+R']]){const l=textNode('label',''),input=document.createElement('input');input.type='radio';input.name='h4-direction';input.value=value;input.checked=value===state.view.scenario;input.onchange=()=>{if(input.checked){$('scenario').value=value;loadView();}};l.append(input,textNode('span',caption));choices.append(l);}bar.append(choices);
   if(m.h4Lines){const key=textNode('div','','h4-line-key');key.setAttribute('aria-label','TL');for(const code of ['EX','AC','PT'])key.append(textNode('span',code,code.toLowerCase()));bar.append(key);}
   const regimes=textNode('div','','prophet-regimes');regimes.append(textNode('span','NDX'));
   for(const r of m.regimes){const box=textNode('div','','regime '+(r.position>0?'long':r.position<0?'short':'flat')),text=r.position===null?'—':r.position>0?'V':r.position<0?'R':'B';box.append(textNode('strong',text),textNode('small',date(r.asOf),'h4-wide'));regimes.append(box);}bar.append(regimes);const heading=textNode('div','','h4-heading');heading.append(article.querySelector('h2'),bar);article.prepend(heading);
  }
  const metrics=textNode('div','','metrics');m.metrics=metrics;article.append(metrics);
  const plot=textNode('div','','chart'),canvas=document.createElement('canvas');canvas.tabIndex=0;canvas.setAttribute('role','img');canvas.setAttribute('aria-label',m.title+' : flèches pour parcourir, + et − pour zoomer');canvas.dataset.panel=m.id;plot.append(canvas);article.append(plot);m.canvas=canvas;
  if(m.kind==='price'||m.id==='equity'){
   const button=textNode('button','','chart-latest');button.type='button';button.id='latest-'+m.id;button.hidden=true;
   button.title='Dernière bougie · même recul · prix ajustés';button.setAttribute('aria-label','Revenir à la dernière bougie et ajuster les prix');
   button.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M4 4L16 12L4 20Z"/><path d="M18 4H21V20H18Z"/></svg>';
   button.onclick=returnToLatest;plot.append(button);m.latestButton=button;
  }
  {const nav=textNode('div','','navigator');nav.append(textNode('span','Parcourir'));const input=document.createElement('input');input.type='range';input.id=m.kind==='price'?'navigator':'navigator-'+m.id;m.navigator=input;input.setAttribute('aria-label','Parcourir l’historique · '+m.title);input.min=0;input.step=.1;bindNavigator(input);nav.append(input);article.append(nav);}
  $('charts').append(article);m.article=article;bind(m);
 }
 if('IntersectionObserver' in window){observer=new IntersectionObserver(entries=>{for(const e of entries){const m=state.panels.find(m=>m.canvas===e.target);if(m)m.visible=e.isIntersecting;}schedule();},{rootMargin:'250px'});state.panels.forEach(m=>observer.observe(m.canvas));}
}
// Every panel slider mirrors the same window, including after pan, pinch or a view change.
// Only an explicit preset selection is highlighted. Any manual date/zoom/pan
// action clears it, including at the data boundary; repaint/hover do not.
function setPeriodPreset(value=null){
 state.periodPreset=value===null?null:String(value);
 updatePeriodControls();
}
function updatePeriodControls(){
 const [since='',end='']=calendarBounds()||[];
 $('since-year').value=since;$('since-year').dataset.active=String(!!since);
 $('end-year').value=end;$('end-year').dataset.active=String(!!end);
 document.querySelectorAll('[data-years]').forEach(b=>{const option=AWW_ANNUAL_VIEW.periodOption(b.dataset.years,state.view?.tf==='h4'),on=option.key===state.periodPreset;b.title=option.months?'Afficher les '+option.months+' derniers mois':option.label;b.textContent=option.label;b.classList.toggle('active',on);b.setAttribute('aria-pressed',String(on));});
}
// One serializable preset carries both calendar bounds through history and
// timeframe changes. Manual navigation clears it; no financial data is rebuilt.
function calendarBounds(){return state.periodPreset?.match(/^calendar:(\d{4}):(\d{4})$/)?.slice(1)||null;}
function sync(keepPreset=false){
 if(!keepPreset)setPeriodPreset();const bounds=calendarBounds(),ytd=state.periodPreset==='ytd';
 Object.assign(state,N.clamp(state.start,state.count,state.dates.length,bounds||ytd||state.periodPreset==='latest'?1:5));
 $('from').value=bounds?bounds[0]+'-01-01':ytd?state.dates.at(-1).slice(0,4)+'-01-01':state.dates[Math.floor(state.start)]?.slice(0,10)||'';
 $('to').value=bounds?bounds[1]+'-12-31':state.dates[Math.min(state.dates.length-1,Math.ceil(state.start+state.count)-1)]?.slice(0,10)||'';
 for(const m of state.panels){const slider=m.navigator;slider.max=Math.max(0,state.dates.length-state.count);slider.value=state.start;slider.disabled=state.count>=state.dates.length;slider.setAttribute('aria-valuetext',date($('from').value)+' → '+date($('to').value));}
 rememberView();schedule();
}
function schedule(){if(!state.raf)state.raf=requestAnimationFrame(()=>{state.raf=0;for(const m of state.panels){if(m.visible)paint(m);}});}
function zoom(f,anchor=.5){Object.assign(state,N.zoom(state.start,state.count,state.dates.length,f,anchor));state.hover=null;sync();}
function zoomRight(f){endViewAction();Object.assign(state,N.zoomRight(state.start,state.count,state.dates.length,f));state.hover=null;state.cursor=null;sync();}
// Pure navigation: same visible bar count, latest bar at right, automatic prices.
// The internal preset permits a one-bar window and highlights no range button.
function returnToLatest(){
 if(!state.dates.length)return;endViewAction();rememberView();
 for(const m of state.panels){if(m.kind==='price'||m.id==='equity')m.yZoom=1;delete m.sliderMarkers;}
 state.start=state.dates.length-state.count;state.hover=null;state.cursor=null;
 setPeriodPreset('latest');sync(true);
}
function updateLatestButton(m){
 const button=m.latestButton,g=m.geom;if(!button||!g)return;
 button.hidden=!(state.start+state.count<state.dates.length-1e-6||state.panels.some(p=>(p.kind==='price'||p.id==='equity')&&Math.abs((p.yZoom||1)-1)>1e-9));
 const size=compact()?40:32,card=m.id==='equity'?m.equityCardBounds:null;
 button.style.right=(g.w-(card?.right??g.right)+4)+'px';
 button.style.top=Math.max(g.top+4,(card?.top??g.bottom)-size-6)+'px';
}
// Remember an early YTD tap while the first calendar is still loading.
// loadView applies this calendar preset once the actual latest year is known.
function years(value){const option=AWW_ANNUAL_VIEW.periodOption(value,state.view?.tf==='h4');if(value==='ytd'&&!option.months){if(!state.dates.length){setPeriodPreset(value);return;}sinceYear(state.dates.at(-1).slice(0,4),'ytd');return;}endViewAction();const v=state.view;if(!v)return;const range=value==='all'?{start:0,count:state.dates.length}:N.windowFor(state.dates,option.months?AWW_ANNUAL_VIEW.monthsBefore(v.to,option.months):(+v.to.slice(0,4)-Number(value))+v.to.slice(4,10),v.to.slice(0,10));if(range){
 // Presets also release manual price-axis stretching on desktop and phone.
 for(const m of state.panels)if(m.kind==='price')m.yZoom=1;
 Object.assign(state,range);state.hover=null;state.cursor=null;setPeriodPreset(option.key);sync(true);}}
// Since starts on 1 January, End stops on 31 December. Changing one retains
// the other. A crossed bound moves its counterpart to the same year. Without
// a pair, Since ends in the latest year; End starts in the first visible year.
function calendarYear(side,year){
 endViewAction();if(year===''){setPeriodPreset();return;}
 if(!/^\d{4}$/.test(String(year)))return;
 const bounds=calendarBounds()||[state.dates[Math.floor(state.start)].slice(0,4),state.dates.at(-1).slice(0,4)];
 bounds[side]=String(year);if(bounds[0]>bounds[1])bounds[1-side]=String(year);
 const range=N.calendarYears(state.dates,...bounds);if(!range)return;
 for(const m of state.panels){m.yZoom=1;delete m.sliderMarkers;}
 Object.assign(state,range);state.hover=null;state.cursor=null;setPeriodPreset('calendar:'+bounds.join(':'));sync(true);
}
function sinceYear(year,preset){
 if(preset!=='ytd'){calendarYear(0,year);return;}
 endViewAction();const range=N.sinceYear(state.dates,year);if(!range)return;
 for(const m of state.panels){m.yZoom=1;delete m.sliderMarkers;}
 Object.assign(state,range);state.hover=null;state.cursor=null;setPeriodPreset('ytd');sync(true);
}
function endAtYear(year){calendarYear(1,year);}
const pos=d=>N.position(state.times,Date.parse(d));
// Calendar span, independent of bar count or zoom. Clamp month ends rather than
// letting Date roll e.g. 31 October back into July when subtracting four months.
// Precomputed confirmed outcomes only; no trading rule or threshold in this reader.
// Cash decisions belong to the following UTC day on CFD H4, like the native
// dailyPlotIndex. Filter outside the calendar before position() clamps its ends.
const regimePlotDate=d=>state.view.tf==='h4'?new Date(Date.parse(d)+86400000).toISOString():d;
function drawADRegimeMarkers(c,m,g,x,end){
 m.regimeMarkerLayout=[];if(!m.regimeMarkers?.length)return;
 end=state.view.tf==='h4'?new Date(Date.parse(end.slice(0,10))-86400000).toISOString().slice(0,10):end;
 c.save();c.lineWidth=1.5;c.globalAlpha=.8;c.lineCap='round';
 for(const mark of m.regimeMarkers){
  const plotted=regimePlotDate(mark.date),time=Date.parse(plotted);
  if(mark.knownAt>end||time<state.times[0]||time>state.times.at(-1))continue;
  const xx=x(pos(plotted));if(xx<g.left+4||xx>g.right-4)continue;
  const yy=g.top+28,dir=mark.side==='up'?-1:1;
  c.strokeStyle=mark.color;c.beginPath();c.moveTo(xx,yy-dir*6);c.lineTo(xx,yy+dir*6);c.moveTo(xx-3.5,yy+dir*2);c.lineTo(xx,yy+dir*6);c.lineTo(xx+3.5,yy+dir*2);c.stroke();
  m.regimeMarkerLayout.push({...mark,x:xx,y:yy});
 }
 c.restore();
}
function visibleZones(zones,end){const groups=new Map();for(const z of zones||[])if(z.knownAt<=end){const old=groups.get(z.group);if(!old||old.knownAt<=z.knownAt)groups.set(z.group,z);}return [...groups.values()].filter(z=>!z.hidden);}
// Coordinates and codes are supplied by the PC. This renderer only clips and
// styles them: no detection, eligibility/counting, projection or market rule.
// Reusable annotation-only canvas. The edge mask never alters price pixels.
function paintH4Layer(c,m,g,draw){
 if(!document.createElement||!c.canvas)return draw(c);
 const layer=m.h4Layer||(m.h4Layer=document.createElement('canvas')),dpr=Math.min(devicePixelRatio||1,3);
 if(layer.width!==c.canvas.width||layer.height!==c.canvas.height){layer.width=c.canvas.width;layer.height=c.canvas.height;}const pen=layer.getContext('2d');
 if(!pen?.setTransform)return draw(c);
 pen.setTransform(1,0,0,1,0,0);pen.clearRect(0,0,layer.width,layer.height);pen.setTransform(dpr,0,0,dpr,0,0);pen.save();pen.beginPath();pen.rect(g.left,g.top,g.right-g.left,g.bottom-g.top);pen.clip();draw(pen);
 pen.restore(); // Geometry is clipped, never faded at the edges.

 c.drawImage(layer,0,0,layer.width/dpr,layer.height/dpr);
}
function drawH4Lines(c,m,g,x,y,end){
 m.h4LineLayout=[];
 for(const l of m.h4Lines||[]){
  const [u,v]=l.ends,a=pos(u[0]),b=pos(v[0]);
  const fade=1;
  // Intersect the actual corridor, never hide it because the terminal bar is
  // outside the viewport. This is display geometry, not a past-state replay.
  if(b<state.start-1||a>state.start+state.count||x(b)<g.left-42||x(a)>g.right+42)continue;
  if(l.code!=='EX'&&l.knownAt!==state.dates.at(-1))continue;
  const left=Math.max(a,state.start-1),right=Math.min(b,state.start+state.count),value=(i,k)=>u[k]+(v[k]-u[k])*(i-a)/(b-a);
  const executed=l.code==='EX',dash=executed?[]:l.code==='AC'?[7,4]:[1,5],alpha=executed?1:l.code==='AC'?.9:.48;
  c.save();c.strokeStyle=l.color;c.lineWidth=executed?2:l.code==='AC'?1.5:1;c.globalAlpha=alpha*fade;c.setLineDash(dash);
  if(executed){c.fillStyle=l.color+'1f';c.beginPath();c.moveTo(x(left),y(value(left,2)));c.lineTo(x(right),y(value(right,2)));c.lineTo(x(right),y(value(right,3)));c.lineTo(x(left),y(value(left,3)));c.closePath();c.fill();}
  for(const k of executed?[1]:l.code==='AC'?[]:[2,3]){c.beginPath();c.moveTo(x(left),y(value(left,k)));c.lineTo(x(right),y(value(right,k)));c.stroke();}
  c.setLineDash([]);c.fillStyle=executed?l.color:'#fff';
  for(const [d,v] of l.dots){const xx=x(pos(d));if(xx<g.left||xx>g.right)continue;c.beginPath();c.arc(xx,y(v),executed?2.4:2.6,0,2*Math.PI);c.fill();if(!executed)c.stroke();}
  c.restore();m.h4LineLayout.push({line:l,dash,alpha,fade,x:x(b),y:y(l.labelAt[1])});
 }
}
function drawH4LineLabels(c,m,g,candles){
 // Inset mobile graduations are text obstacles too: a tiny AC/PT card must
 // remain readable instead of landing on an axis number or the YTD readout.
 const previous=m.h4LabelLayout||[],boxes=[...(m.markerLayout||[]).map(p=>p.box).filter(Boolean),...(m.axisTextBoxes||[]),...(m.ytdLayout?[m.ytdLayout]:[])];m.h4LabelLayout=[];m.h4LabelPaints=[];
 for(const p of m.h4LineLayout||[])if(p.line.code==='AC'&&p.x>=g.left&&p.x<=g.right)boxes.push({left:g.right-68,right:g.right,top:p.y-13,bottom:p.y+13});
 const hits=box=>candles.some(p=>box.left<p.right+8&&box.right>p.left-8&&box.top<p.bottom+8&&box.bottom>p.top-8);
 c.save();c.font='600 10px Segoe UI,Arial,sans-serif';c.textAlign='center';c.textBaseline='middle';
 for(const p of m.h4LineLayout||[]){
  if(p.line.code==='EX')continue; // Existing EX # marker identifies this line.
  const old=previous.find(v=>v.line===p.line),preferred=old?{left:old.left+p.x-old.x,right:old.right+p.x-old.x,top:old.top+p.y-old.y,bottom:old.bottom+p.y-old.y}:null;
  const guide=AWW_ANNUAL_VIEW.h4TriggerGuide(g,p.x,p.y,(g.right-g.left)/state.count,p.line.color);
  const box=p.line.code==='AC'?AWW_ANNUAL_VIEW.placeH4TriggerCard(g,guide,c.measureText(p.line.code).width+10,17,b=>hits(b)||boxes.some(a=>AWW_ANNUAL_VIEW.textBoxesOverlap(a,b,4)),gesture?preferred:null):placeEquityLabel(p.x,p.y,c.measureText(p.line.code).width+10,17,g,boxes,hits,preferred);if(!box)continue;
  boxes.push(box);const xx=(box.left+box.right)/2,yy=(box.top+box.bottom)/2;
  c.strokeStyle=p.line.color;c.lineWidth=1;c.globalAlpha=.65*p.fade;c.setLineDash([3,3]);c.beginPath();if(p.line.code!=='AC'){c.moveTo(xx,yy);c.lineTo(p.x,p.y);c.stroke();}c.setLineDash([]);c.globalAlpha=p.fade;
  m.h4LabelPaints.push(pen=>{pen.save();pen.globalAlpha=p.fade;pen.setLineDash([]);pen.font='600 10px Segoe UI,Arial,sans-serif';pen.textAlign='center';pen.textBaseline='middle';pen.fillStyle='rgba(255,255,255,.82)';pen.fillRect(box.left,box.top,box.right-box.left,box.bottom-box.top);pen.strokeStyle='#d5e0eb';pen.lineWidth=.7;pen.strokeRect(box.left,box.top,box.right-box.left,box.bottom-box.top);pen.fillStyle=p.line.color;pen.fillText(p.line.code,xx,yy);pen.restore();});
  m.h4LabelLayout.push({...p,...box});
 }c.restore();
}
// Historical decoration only. The builder supplies dates and final colours;
// historical completed outcome stays visible while panning; no private rule.
function drawDivergenceFrames(c,m,g,x,end){
 m.divergenceFrameLayout=[];if(m.id!=='ad')return;
 c.save();c.font='bold 10px Segoe UI,Arial,sans-serif';c.textAlign='center';c.setLineDash([]);c.lineWidth=.8;
 const lanes=[[],[]];
 for(const z of visibleZones(m.zones,end)){
  if(!z.framedAt||regimePlotDate(z.framedAt)>end)continue;
  const a=x(pos(z.from)),b=x(pos(z.to));if(b<g.left||a>g.right)continue;
  const outcome=z.outcome||null;
  const label='D−'+(outcome?' · NDX '+fmt(outcome.percent,1)+' %':''),w=c.measureText(label).width+10,cx=Math.max(g.left+w/2+2,Math.min(g.right-w/2-2,(Math.max(g.left,a)+Math.min(g.right,b))/2));
  const lane=lanes.findIndex(items=>items.every(q=>cx+w/2+4<q[0]||cx-w/2-4>q[1]));if(lane<0)continue;
  lanes[lane].push([cx-w/2,cx+w/2]);const yy=g.top+4+lane*18;
  if(outcome){c.fillStyle=outcome.fill;c.fillRect(cx-w/2,yy,w,15);}
  c.fillStyle=outcome?.ink||z.color;c.strokeStyle=z.color;c.strokeRect(cx-w/2,yy,w,15);c.fillText(label,cx,yy+11);
  m.divergenceFrameLayout.push({from:z.from,to:z.to,framedAt:z.framedAt,label,outcome,x:cx-w/2,y:yy,w,h:15});
 }c.restore();
}
function drawDowKey(c,m,g){
 const s=m.series.find(s=>s.key==='dow');if(!s)return;
 c.save();c.font='10px Segoe UI,Arial,sans-serif';c.fillStyle=s.color;c.strokeStyle=s.color;c.lineWidth=1.4;c.setLineDash([]);
 const xx=g.left+7,yy=g.bottom-(compact()?25:9);c.beginPath();c.moveTo(xx,yy-3);c.lineTo(xx+12,yy-3);c.stroke();c.textAlign='left';c.fillText('Dow',xx+16,yy);c.restore();
}
function getSlice(series){const a=Math.max(0,N.lower(series.indices,state.start)-1),b=N.lower(series.indices,state.start+state.count)+1;return series.points.slice(a,b);}
function scale(values,log,zero){let lo=Infinity,hi=-Infinity;for(const v of values)if(Number.isFinite(v)&&(!log||v>0)){lo=Math.min(lo,v);hi=Math.max(hi,v);}if(lo===Infinity){lo=0;hi=1;log=false;}if(zero&&!log){lo=Math.min(0,lo);hi=Math.max(0,hi);}if(log){lo=Math.log(lo);hi=Math.log(hi);}const margin=(hi-lo)*.10||Math.abs(hi)*.05||1;return {lo:lo-margin,hi:hi+margin,log};}
/** Place a symbol + caption outside nearby candle wicks. This is screen-space
 * layout only: dates, execution prices and financial results never change.
 * Crowded zoomed-out views keep symbols; captions reappear as space permits. */
// Presentation palette only. Classification is computed privately, never here.
function riskIndexStyle(label){
 const palette={LOW:['#e6f1fa','#174c78','#b0c9de'],HIGH:['#b9d7ef','#123e62','#689dc3'],'VERY HIGH':['#f4c9cd','#7c2030','#d58b96'],MAXIMAL:['#9f3549','#ffffff','#7c2030']};
 const [fill,ink,border]=palette[label]||['#e4e9ee','#52677c','#c4cdd6'];return {fill,ink,border};
}
function markerLayout(items,candles,bounds,measure,showText){
 const placed=[],overlaps=(a,b)=>a.left<b.right+3&&a.right>b.left-3&&a.top<b.bottom+3&&a.bottom>b.top-3;
 const priority=m=>m.peer?2:m.shape==='mm200'?3:m.shape==='bam'||m.shape==='bam-reference'?1:0;
 for(const item of [...items].sort((a,b)=>priority(a.mark)-priority(b.mark)||a.x-b.x)){
  const mark=item.mark,above=mark.side==='down'||mark.side==='neutral'||mark.shape==='exit';
  let candidate=null;
  // Compact captions only. No trading instructions exist in the public data.
  const variants=showText||item.outcome||mark.risk?[true,...(!mark.labelOnly?[false]:[])]:mark.labelOnly?[]:[false];
  for(const caption of variants){
   const width=caption?Math.max(14,measure(mark.label)+10,item.outcome?measure('Top-bottom '+fmt(item.outcome.percent,1)+' %')+10:0,mark.risk?measure('RI · '+mark.risk)+10:0):12,height=caption?30+(item.outcome?14:0)+(mark.risk?14:0):12;
   if(width>bounds.right-bounds.left-4)continue;
   // A numeric TP caption near the right edge can be trapped between the
   // last candle and an earlier signal. Try adjacent columns before hiding it.
   // The dashed leader stays attached to the original date/level.
   const centers=[...new Set(((mark.shape==='tp'||mark.risk)&&caption?[item.x,item.x-width-8,item.x+width+8,item.x-2*(width+8),item.x+2*(width+8)]:[item.x]).map(x=>Math.max(bounds.left+width/2+2,Math.min(bounds.right-width/2-2,x))))];
   for(const center of centers){
   const near=candles.filter(r=>r.right>=center-width/2-3&&r.left<=center+width/2+3);
   const high=Math.min(item.y,...near.map(r=>r.top)),low=Math.max(item.y,...near.map(r=>r.bottom));
   for(const sign of [above?-1:1,above?1:-1]){
    for(let lane=0;lane<10;lane++){
     const tip=(sign<0?high-12:low+12)+sign*lane*(height+4);
     const box={left:center-width/2,right:center+width/2,top:sign<0?tip-height:tip,bottom:sign<0?tip:tip+height};
     if(box.top<bounds.top+2||box.bottom>bounds.bottom-2)continue;
     if(placed.some(p=>overlaps(box,p.box))||near.some(r=>overlaps(box,r)))continue;
     candidate={...item,center,tip,sign,caption,box};break;
    }if(candidate)break;
   }if(candidate)break;
   }if(candidate)break;
  }
  if(candidate)placed.push(candidate);
 }
 return placed;
}
/** Range sliders move every chart. Keep already placed/hidden captions stable
 * relative to their candles until release, instead of re-solving collisions on
 * every input tick. This memory is presentation only and never exported.
 * Known labels may finish crossing the edge; release restores the date cutoff. */
function bindNavigator(input){
 let active=false;
 const begin=()=>{if(active)return;beginViewAction('slider');active=true;const asOf=state.dates[Math.min(state.dates.length-1,Math.floor(state.start+state.count-1))];
  for(const m of state.panels)if(m.kind==='price'){
   const placements=new Map((m.markerItems||[]).map(p=>[p.mark,null]));
   for(const p of m.markerLayout||[])placements.set(p.mark,p);
   m.sliderMarkers={asOf,placements,currentCorrection:m.currentCorrectionLayout};
  }
 };
 const end=()=>{if(!active)return;active=false;for(const m of state.panels)delete m.sliderMarkers;endViewAction();schedule();};
 input.onpointerdown=e=>{if(e.button===0)begin();};
 input.onkeydown=e=>{if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','PageUp','PageDown','Home','End'].includes(e.key))begin();else if(e.key==='Escape')end();};
 input.oninput=()=>{begin();state.start=+input.value;state.hover=null;state.cursor=null;sync();};
 input.onchange=input.onpointerup=input.onpointercancel=input.onlostpointercapture=input.onblur=end;
}
function sliderMarkerLayout(m,items,candles,bounds,measure,showText){
 if(!m.sliderMarkers)return markerLayout(items,candles,bounds,measure,showText);
 const cache=m.sliderMarkers.placements,placed=[];
 for(const item of items){
  if(!cache.has(item.mark))cache.set(item.mark,markerLayout([item],candles,bounds,measure,showText)[0]||null);
  const old=cache.get(item.mark);if(!old)continue;
  const dx=item.x-old.x,dy=item.y-old.y,box={left:old.box.left+dx,right:old.box.right+dx,top:old.box.top+dy,bottom:old.box.bottom+dy};
  // Retain the leader as well as the caption until the whole drawing leaves.
  if(Math.max(item.x,box.right)<bounds.left||Math.min(item.x,box.left)>bounds.right||Math.max(item.y,box.bottom)<bounds.top||Math.min(item.y,box.top)>bounds.bottom)continue;
  placed.push({...old,x:item.x,y:item.y,center:old.center+dx,tip:old.tip+dy,box});
 }
 return placed;
}
/** Current observed correction, not the latest closing-price decline.
 * Daily troughs attach to their containing weekly candle (ceil, not a date
 * interpolation). The engine supplies the result; the reader only places it.
 * Slider drags preserve the label offset until the drawing leaves the plot. */

function drawMarkerSymbol(c,mark,xx,cy){
 if(mark.labelOnly)return;
 c.strokeStyle=mark.color;c.fillStyle=(mark.hollow??mark.peer)?'white':mark.color;c.lineWidth=1.5;
 c.setLineDash(mark.provisional||mark.hollow?[2,2]:[]);c.beginPath();
 if(mark.shape==='exit'){c.moveTo(xx-4,cy-4);c.lineTo(xx+4,cy+4);c.moveTo(xx-4,cy+4);c.lineTo(xx+4,cy-4);}
 else if(mark.shape==='mm200'){
  const dir=mark.side==='up'?-1:1,tip=cy+dir*5;
  c.moveTo(xx,cy-dir*5);c.lineTo(xx,tip);c.moveTo(xx-4,tip-dir*4);c.lineTo(xx,tip);c.lineTo(xx+4,tip-dir*4);
 }else if(mark.shape==='bam'||mark.shape==='bam-reference'){c.moveTo(xx,cy-5);c.lineTo(xx+5,cy);c.lineTo(xx,cy+5);c.lineTo(xx-5,cy);c.closePath();c.fill();}
 else if(mark.shape==='circle'||mark.shape==='tp'){c.arc(xx,cy,5,0,Math.PI*2);c.fill();}
 else if(mark.shape==='square'){c.rect(xx-5,cy-5,10,10);c.fill();}
 else{const direction=mark.side==='down'||mark.side==='neutral'?1:-1;c.moveTo(xx,cy+5*direction);c.lineTo(xx-5,cy-4*direction);c.lineTo(xx+5,cy-4*direction);c.closePath();c.fill();}
 c.stroke();c.setLineDash([]);
}
// Display only: no financial calculation. The fixed card uses canvas bounds;
// the five historical arrows follow their own curve and disappear outside zoom.
// Presentation preferences survive timeframe/scenario changes, never enter the
// financial cache or public data export. Hidden series retain their original data.
const equityView={hidden:new Set(['lqq','eqac','dsp5']),singleScale:true};
function equityEntries(m){return m.performance.map((p,i)=>({p,i})).filter(({p})=>!equityView.hidden.has(p.key));}
function equityMargin(m,w){const n=equityEntries(m).length;return n?(w<600?31:42)*(equityView.singleScale?1:n)+6:8;}
// Display-only rebasing. Keep raw points and raw-coordinate ranges so curves,
// historical DD/MAE arrows and collision geometry all retain the same mapping.
// The first visible observation is 100, independently for each strategy.
function equityValue(m,i,value){const base=m.equityBases?.[i]?.value;return base>0?value/(base/100):value;}
function equityRanges(m,points,start,end=Infinity){
 const slices=m.series.map(points);
 m.equityBases=slices.map(ps=>{const p=ps.find(p=>(p.idx??p.i)>=start-.5&&Number.isFinite(p.v));return {value:p?.v,date:p?.date};});
 // Bind statistics to the actual plotted endpoint dates, not padded calendar
 // limits. All daily closes inside those endpoints remain available in weekly.
 const from=m.equityBases[0]?.date,to=slices[0]?.findLast(p=>(p.idx??p.i)<=end+.5&&Number.isFinite(p.v))?.date;
 const cache=m.windowCache;
 if(m.windowData&&(!cache||cache.data!==m.windowData||cache.from!==from||cache.to!==to)){
  m.windowPerformance=AWW_ANNUAL_VIEW.windowStats(m.windowData,from,to);
  m.windowCache={data:m.windowData,from,to};
 }
 // Reuse the display projection while only the cursor/right edge changes.
 const referenceCache=m.lqqWindowCache,referenceFrom=m.equityBases[2]?.date;
 if(m.lqq&&(!referenceCache||referenceCache.source!==m.lqq||referenceCache.series!==m.series[2].points||referenceCache.from!==referenceFrom)){
  m.lqqWindow=AWW_ANNUAL_VIEW.referenceWindow(m.lqq,m.series[2].points,referenceFrom);
  m.lqqWindowCache={source:m.lqq,series:m.series[2].points,from:referenceFrom};
 }
 AWW_ANNUAL_VIEW.prepareReferences(m);
 const offsets=m.equityBases.map(b=>b.value>0?Math.log(b.value/100):0);
 const values=slices.map((ps,i)=>ps.map(p=>p.v).filter(v=>Number.isFinite(v)&&v>0).map(v=>Math.log(v)-offsets[i]));
 const extent=vs=>{const lo=vs.length?Math.min(...vs):0,hi=vs.length?Math.max(...vs):1,pad=(hi-lo)*.09||.1;return {min:lo-pad,max:hi+pad};};
 if(m.lqq&&!equityView.hidden.has('lqq')&&!equityView.hidden.has('sys2'))values[2].push(...m.lqqWindow.points.filter(p=>p.i>=start&&p.i<=end&&p.v>0).map(p=>Math.log(p.v)-offsets[2]));
 for(const r of AWW_ANNUAL_VIEW.activeReferences(m,equityView.hidden))values[r.axis].push(...r.window.points.filter(p=>p.i>=start&&p.i<=end&&p.v>0).map(p=>Math.log(p.v)-offsets[r.axis]));
 const shared=equityView.singleScale?extent(equityEntries(m).flatMap(({i})=>values[i])):null;
 return values.map((vs,i)=>{const r=shared||extent(vs);return {min:r.min+offsets[i],max:r.max+offsets[i]};});
}
function setEquityDisplay(key,checked){
 if(key==='singleScale')equityView.singleScale=checked;
 else if(checked)equityView.hidden.delete(key);else equityView.hidden.add(key);
 if(key==='eqac'&&checked)equityView.hidden.delete('equity');if(key==='dsp5'&&checked&&equityView.hidden.has('equity')&&equityView.hidden.has('sys2'))equityView.hidden.delete('sys2');
 if(key==='lqq'&&checked)equityView.hidden.delete('sys2');if(key==='sys2'&&!checked)equityView.hidden.add('lqq');
}
function equityControls(m){
 const controls=textNode('div','','equity-controls');controls.setAttribute('role','group');controls.setAttribute('aria-label','Courbes et échelle des courbes de capital');
 const choices=m.performance.map((p,i)=>({key:p.key,label:['B&H','LVR1','LVR2'][i],title:p.label,color:p.color,checked:!equityView.hidden.has(p.key)}));
 if(m.lqq)choices.push({key:'lqq',label:'LQQ',title:'LQQ · EUR brut · '+m.lqq.from+' — '+m.lqq.through,color:m.lqq.color,checked:!equityView.hidden.has('lqq')});
 for(const [key,label] of [['eqac','EQAC'],['dsp5','DSP5']]){const r=m.references?.find(r=>r.toggle===key);if(r)choices.push({key,label,title:r.label+' · '+r.currency+' · '+r.from+' — '+r.through,color:r.color,checked:!equityView.hidden.has(key)});}
 choices.push({key:'singleScale',label:'Échelle unique',title:'Cochée : graphe semi-logarithmique avec une échelle commune. Décochée : une échelle adaptative par courbe.',color:'#52677c',checked:equityView.singleScale});
 for(const o of choices){const label=textNode('label',''),input=document.createElement('input');label.title=o.title;label.style.color=o.color;input.type='checkbox';input.id='equity-show-'+o.key;input.checked=o.checked;input.onchange=()=>{setEquityDisplay(o.key,input.checked);for(const key of ['lqq','eqac','dsp5','equity','sys2']){const el=document.getElementById('equity-show-'+key);if(el)el.checked=!equityView.hidden.has(key);}paint(m);};label.append(input,textNode('span',o.label));controls.append(label);}
 return controls;
}
// Context uses the already plotted exposure, not new trade rules. The steps
// match the panel above (end-of-day / end-of-week), including intermediate 50% -> 100%.
// Shared backdrop for Nasdaq, exposure and capital. Read only the selected
// exposure series (cash LVR1/LVR2, or Prophet in H4); never infer trades from
// price colours. Cached steps retain the regime already active at the left edge.
// Keep the historic equityExposure* cache names for the rendering contract.
function drawEquityExposure(c,m,g,x,points=[]){
 // H4 uses only the selected, already exported position series. Zero has no
 // tint; positive/negative use green/red. Cash daily/weekly stays red/blue.
 const h4=state.view.tf==='h4';
 if(m.equityExposureSource!==points){
  m.equityExposureSource=points;m.equityExposureSteps=[];let previous=null;
  for(const p of points){if(!Number.isFinite(p.v)||p.v===previous)continue;m.equityExposureSteps.push({index:p.idx??p.i,value:p.v,buy:p.v>0&&(previous===null||p.v>previous)});previous=p.v;}
 }
 const steps=m.equityExposureSteps;m.equityExposureLayout=[];
 if(m.performance&&!equityEntries(m).length)return;
 c.save();c.beginPath();c.rect(g.left,g.top,g.right-g.left,g.bottom-g.top);c.clip();
 for(let i=0;i<steps.length;i++){
  const p=steps[i],a=x(p.index),b=i+1<steps.length?x(steps[i+1].index):g.right;
  const left=Math.max(g.left,a),right=Math.min(g.right,b);
  if(right>left&&(h4?p.value!==0:p.value<=0)){
   const kind=p.value<0?'short':p.value>0?'long':'flat';
   c.fillStyle=kind==='short'?'rgba(193,77,91,.07)':kind==='long'?'rgba(19,132,108,.07)':'rgba(22,117,197,.085)';
   c.fillRect(left,g.top,right-left,g.bottom-g.top);m.equityExposureLayout.push({kind,left,right,index:p.index});
  }
  if(m.performance&&p.buy&&a>=g.left&&a<=g.right){c.strokeStyle='rgba(19,132,108,.25)';c.lineWidth=1;c.setLineDash(p.value<100?[3,3]:[]);c.beginPath();c.moveTo(a,g.top);c.lineTo(a,g.bottom);c.stroke();m.equityExposureLayout.push({kind:'buy',x:a,index:p.index,value:p.value});}
 }c.restore();
}
// Hover labels read existing capital observations. Labels share a compact
// right-hand stack when curves are close; connector dots retain their true y.
// Both readers call this on the interaction layer so mouse movement does not
// invalidate the private renderer's cached financial/annotation background.
function drawEquityHover(c,m,g,x,index,day){
 m.equityHoverLabels=[];
 if(index===null||index===undefined||x(index)<g.left||x(index)>g.right)return;
 const labels=[],height=20,gap=3;
 c.save();c.font=(g.w<600?'600 10px':'600 11px')+' Segoe UI,Arial,sans-serif';c.textBaseline='middle';
 const entries=equityEntries(m);for(const r of AWW_ANNUAL_VIEW.activeReferences(m,equityView.hidden))entries.push({p:{key:r.key,color:r.color},i:r.axis,reference:r.window});if(m.lqq&&!equityView.hidden.has('lqq')&&!equityView.hidden.has('sys2'))entries.push({p:{key:'lqq',color:m.lqq.color},i:2,reference:m.lqqWindow});
 for(const {p,i,reference} of entries){
  const points=reference?reference.points:m.series[i].points;let a=0,b=points.length;
  while(a<b){const mid=(a+b)>>1;if((points[mid].idx??points[mid].i)<=index)a=mid+1;else b=mid;}
  const point=points[a-1],range=m.seriesRanges[i];if(!point||!(point.v>0)||(reference&&point.date!==day))continue;
  const xx=x(point.idx??point.i),yy=g.bottom-(Math.log(point.v)-range.min)/(range.max-range.min)*(g.bottom-g.top);
  if(xx<g.left||xx>g.right||yy<g.top||yy>g.bottom)continue;
  const value=equityValue(m,i,point.v),text=(reference?(p.key==='lqq'?'LQQ':p.key==='eqac'?'EQAC':'DSP5·'+(i===1?'1':'2')):['B&H','LVR1','LVR2'][i])+' '+fmt(value,0),width=Math.min(g.w-20,c.measureText(text).width+12),right=compact()?g.right-3:g.w-3;
  labels.push({key:p.key,color:p.color,value,date:point.date,index:point.idx??point.i,x:xx,y:yy,text,width,right,left:right-width,top:Math.max(g.top,Math.min(g.bottom-height,yy-height/2))});
 }
 labels.sort((a,b)=>a.y-b.y);
 for(let i=1;i<labels.length;i++)labels[i].top=Math.max(labels[i].top,labels[i-1].top+height+gap);
 for(let i=labels.length-1;i>=0;i--)labels[i].top=Math.min(labels[i].top,i===labels.length-1?g.bottom-height:labels[i+1].top-height-gap);
 for(const l of labels){
  c.save();c.beginPath();c.rect(g.left,g.top,g.right-g.left,g.bottom-g.top);c.clip();c.strokeStyle=l.color;c.globalAlpha=.45;c.lineWidth=1;c.setLineDash([3,3]);c.beginPath();c.moveTo(l.x,l.y);c.lineTo(g.right,l.y);c.stroke();c.restore();
  c.fillStyle=l.color;c.beginPath();c.arc(l.x,l.y,3,0,Math.PI*2);c.fill();
  c.strokeStyle=l.color;c.lineWidth=1;c.setLineDash([]);c.beginPath();c.moveTo(g.right,l.y);c.lineTo(l.left,l.top+height/2);c.stroke();
  c.fillStyle=compact()?'rgba(255,255,255,.4)':l.color;c.fillRect(l.left,l.top,l.width,height);c.fillStyle=compact()?l.color:'#fff';c.textAlign='left';c.fillText(l.text,l.left+6,l.top+height/2,l.width-12);
  l.bottom=l.top+height;
 }
 if(labels.length){const text=cursorDate(day,state.view.tf!=='weekly'),width=c.measureText(text).width+12,xx=Math.max(g.left+width/2,Math.min(g.right-width/2,x(index)));c.fillStyle='#15356b';c.fillRect(xx-width/2,g.bottom+(compact()?15:5),width,compact()?14:20);c.fillStyle='#fff';c.textAlign='center';c.fillText(text,xx,g.bottom+(compact()?22:15));}
 c.restore();m.equityHoverLabels=labels;
}
function equityTick(v){return v>=1e9?fmt(v/1e9,0)+'G':v>=1e6?fmt(v/1e6,0)+'M':v>=1e3?fmt(v/1e3,0)+'k':fmt(v,0);}
// Measure each inset axis including its title, rather than allocating a
// fixed 48 px column. Preserve the B&H/LVR1/LVR2 order with a 4 px clear gap.
// All positions are drawing coordinates: no financial series are transformed.
function drawEquityAxes(c,m,g){
 const {left,right,top,bottom,w}=g,inside=g.insetAxes,step=w<600?31:42;
 c.save();c.font=(w<600?'700 9px':'600 10px')+' Segoe UI,Arial,sans-serif';
 const entries=equityEntries(m),axes=equityView.singleScale?entries.slice(0,1):entries;
 m.equityBaseLine=null;
 const columns=axes.map(({p,i})=>{const r=m.seriesRanges[i],base=m.equityBases[i].value,title=equityView.singleScale?'Base 100':['B&H','LVR1','LVR2'][i];
  const values=AWW_ANNUAL_VIEW.roundTicks(equityValue(m,i,Math.exp(r.min)),equityValue(m,i,Math.exp(r.max)),4,true,[100]);
  const lineYs=values.map(v=>bottom-(Math.log(v*base/100)-r.min)/(r.max-r.min)*(bottom-top)),ticks=values.map(equityTick);
  const tickYs=lineYs.map(yy=>inside?Math.max(top+11,Math.min(bottom+9,yy+4)):yy+4);
  return {p,i,title,values,lineYs,ticks,tickYs,width:Math.ceil(Math.max(...[title,...ticks].map(t=>c.measureText(t).width)))};});
 let edge=right-4;
 for(let j=columns.length-1;j>=0;j--){const col=columns[j];col.x=inside?edge:right+step*(j+.5)+3;col.left=inside?edge-col.width:col.x-col.width/2;col.right=inside?edge:col.x+col.width/2;edge=col.left-4;}
 m.equityAxisCount=columns.length;m.equityAxisLayout=columns.map(({p,i,...layout})=>layout);
 // One full-width grid, referenced to the first visible axis. Independent
 // axes retain their own round ticks and short tick marks, not a false alignment.
 m.insetAxisWidth=inside&&columns.length?right-Math.min(...columns.map(col=>col.left))+5:0;
 // The period rail clears pixels 0..31. Keep the whole heading below it,
 // including when the share button shifts the title inside the plot.
 const titleY=Math.max(44,top-4),titleEdge=Math.max(0,...columns.map(col=>col.right)),titleShift=Math.max(0,titleEdge-AWW_ANNUAL_VIEW.chartActionRight(g,titleY-11,titleY+3,titleEdge));
 for(const [j,col] of columns.entries()){
  col.lineYs.forEach((yy,k)=>{c.strokeStyle=col.values[k]===100?'#bdcbd9':'#e9eef4';c.beginPath();c.moveTo(j===0?left:col.left,yy);c.lineTo(j===0?right:col.right,yy);c.stroke();
   if(j===0&&col.values[k]===100)m.equityBaseLine={value:100,y:yy};});
  c.globalAlpha=inside?.7:1;c.fillStyle=equityView.singleScale?'#52677c':col.p.color;
  if(!equityView.singleScale)AWW_ANNUAL_VIEW.axisText(c,m,g,col.title,col.x-titleShift,titleY,inside?'right':'center');
  col.ticks.forEach((label,k)=>AWW_ANNUAL_VIEW.axisText(c,m,g,label,col.x,col.tickYs[k],inside?'right':'center',{value:col.values[k],lineY:col.lineYs[k]}));
 }c.restore();
 const first=columns[0];
 const r=first&&m.seriesRanges[first.i],base=first&&m.equityBases[first.i].value;
 AWW_ANNUAL_VIEW.equityBaseLabel(c,m,g,r?bottom-(Math.log(base)-r.min)/(r.max-r.min)*(bottom-top):NaN);
}
function equityCard(c,m,g){
 if(g.w*(g.uiScale||1)<600){const rows=equityEntries(m).map(({p,i})=>{const {stats,mae}=m.windowPerformance?.performance[i]||p;return {label:['B&H','LVR1','LVR2'][i],color:p.color,cagr:stats.cagr,dd:stats.maxDrawdown,mae:p.key==='buyHold'?null:mae?.percent};});const p=m.windowPerformance||m.stats;const b=AWW_ANNUAL_VIEW.compactPerformanceCard(c,g,rows,date(p.from)+' – '+date(p.to));b.lines=rows.map(r=>({color:r.color,main:'CAGR '+r.label+' : '+fmt(r.cagr,2)+' %/an',sub:'○ Max Drawdown '+fmt(r.dd,2)+' %'+(r.label==='B&H'?'':' · △ MAE '+fmt(r.mae,2)+' %')}));return b;}
 const small=g.w<600,pad=8,main=(small?'700 10px':'600 12px')+' Segoe UI,Arial,sans-serif',sub=(small?'600 9px':'500 10px')+' Segoe UI,Arial,sans-serif';
 const lines=equityEntries(m).map(({p,i})=>{const {stats,mae}=m.windowPerformance?.performance[i]||p;return {color:p.color,main:'CAGR '+['B&H','LVR1','LVR2'][i]+' : '+fmt(stats.cagr,2)+' %/an',sub:'○ MDD '+fmt(stats.maxDrawdown,2)+' %'+(p.key==='buyHold'?'':' · △ MAE '+fmt(mae?.percent,2)+' %')};});
 const period='Période : '+date((m.windowPerformance||m.stats).from)+' – '+date((m.windowPerformance||m.stats).to);let width=0;
 c.save();c.font=main;for(const l of lines)width=Math.max(width,c.measureText(l.main).width);c.font=sub;for(const l of lines)width=Math.max(width,c.measureText(l.sub).width);width=Math.max(width,c.measureText(period).width);c.restore();
 const cardRight=g.right-4;width=Math.min(width+pad*2,cardRight-g.left-4);const height=24+29*lines.length;
 // Bottom ticks are below the mobile plot. Keep a small gap above its axis,
 // with the card fixed in the viewport while dates move underneath it.
 const bottomGap=5;
 return {left:cardRight-width,right:cardRight,top:g.bottom-height-bottomGap,bottom:g.bottom-bottomGap,width,height,pad,main,sub,lines,period};
}
function drawEquityCard(c,m,g){
 if(!equityEntries(m).length){m.equityCardBounds=null;c.save();c.fillStyle='#52677c';c.font='12px Segoe UI,Arial,sans-serif';c.textAlign='center';c.fillText('Sélectionnez une courbe dans le titre.',(g.left+g.right)/2,(g.top+g.bottom)/2);c.restore();return;}
 const b=equityCard(c,m,g);m.equityCardBounds=b;
 if(b.compactTable){AWW_ANNUAL_VIEW.drawCompactPerformanceCard(c,b);return;}
 c.save();c.fillStyle=compact()?'rgba(255,255,255,.9)':'rgba(248,250,253,.94)';c.fillRect(b.left,b.top,b.width,b.height);c.strokeStyle=compact()?'rgba(89,113,138,.2)':'#dbe2ec';c.strokeRect(b.left,b.top,b.width,b.height);c.textAlign='left';c.textBaseline='middle';
 b.lines.forEach((l,i)=>{const yy=b.top+13+i*29;c.fillStyle=l.color;c.font=b.main;c.fillText(l.main,b.left+b.pad,yy,b.width-2*b.pad);c.font=b.sub;AWW_ANNUAL_VIEW.drawRiskLegendLine(c,l.sub,b.left+b.pad,yy+12,l.color);});
 c.fillStyle='#52677c';c.font='9px Segoe UI,Arial,sans-serif';c.fillText(b.period,b.left+b.pad,b.bottom-9,b.width-2*b.pad);c.restore();
}
// Project every visible curve into narrow screen columns once per redraw.
// Keeping separate envelopes per curve preserves empty space between curves.
// Candidate labels then avoid all traces (including segments between samples),
// the fixed statistics card and one another, with an 8 px visual clearance.
function equityCurveObstacles(m,g,x){
 const step=4,n=Math.ceil((g.right-g.left)/step)+1,bands=[];
 for(const {i,points} of [...equityEntries(m).map(e=>({...e,points:m.series[e.i].points})),...AWW_ANNUAL_VIEW.activeReferences(m,equityView.hidden).map(r=>({i:r.axis,points:r.window.points})),...(m.lqq&&!equityView.hidden.has('lqq')&&!equityView.hidden.has('sys2')?[{i:2,points:m.lqqWindow.points}]:[])]){
  const lo=new Float64Array(n).fill(Infinity),hi=new Float64Array(n).fill(-Infinity),r=m.seriesRanges[i];let prev=null;
  for(const p of points){
   if(!(p.v>0)||!Number.isFinite(p.v)){prev=null;continue;}
   const q={x:x(p.idx??p.i),y:g.bottom-(Math.log(p.v)-r.min)/(r.max-r.min)*(g.bottom-g.top)};
   const a=prev||q,b=q;prev=q;
   if(b.x<g.left||a.x>g.right)continue;
   const left=Math.max(g.left,a.x),right=Math.min(g.right,b.x),first=Math.max(0,Math.floor((left-g.left)/step)),last=Math.min(n-1,Math.floor((right-g.left)/step));
   for(let j=first;j<=last;j++){
    const l=Math.max(left,g.left+j*step),rr=Math.min(right,g.left+(j+1)*step),dy=b.y-a.y,dx=b.x-a.x;
    const yl=dx?a.y+(l-a.x)*dy/dx:a.y,yr=dx?a.y+(rr-a.x)*dy/dx:b.y;
    lo[j]=Math.min(lo[j],yl,yr);hi[j]=Math.max(hi[j],yl,yr);
   }
  }bands.push({lo,hi});
 }
 return box=>{
  const pad=8,first=Math.max(0,Math.floor((box.left-pad-g.left)/step)),last=Math.min(n-1,Math.floor((box.right+pad-g.left)/step));
  for(const {lo,hi} of bands)for(let j=first;j<=last;j++)if(lo[j]<=box.bottom+pad&&hi[j]>=box.top-pad)return true;
  return false;
 };
}
function placeEquityLabel(px,py,width,height,g,boxes,hitsCurve,preferred){
 // Keep the same 8 px clearance at the plot edges as around curves;
 // a clipped label near the edge must not touch a curve entering the viewport.
 const clampX=v=>Math.max(g.left+8,Math.min(g.right-width-8,v)),xs=new Set([clampX(px-width/2)]),ys=new Set(),candidates=[];
 for(let left=g.left+8;left<=g.right-width-8;left+=Math.max(24,width/2))xs.add(left);
 xs.add(g.right-width-8);
 for(const dy of [-50,50,-76,76])ys.add(py+dy-height/2);
 for(let top=g.top+8;top<=g.bottom-height-8;top+=height+7)ys.add(top);
 const overlap=(a,b)=>a.left<b.right+5&&a.right>b.left-5&&a.top<b.bottom+5&&a.bottom>b.top-5;
 // Reuse the offset while it is still clear: hover and small pans must not
 // shuffle labels merely because another candidate became slightly closer.
 const fits=box=>box.left>=g.left+8&&box.right<=g.right-8&&box.top>=g.top+8&&box.bottom<=g.bottom-8&&!boxes.some(b=>overlap(box,b))&&!hitsCurve(box),connector=box=>AWW_ANNUAL_VIEW.labelLeader(box,px,py),leaders=boxes.leaders??=[];
 if(preferred&&fits(preferred)&&!AWW_ANNUAL_VIEW.leaderCrossings(connector(preferred),leaders)){leaders.push(connector(preferred));return preferred;}
 for(const left of xs)for(const top of ys){
  if(left<g.left+8||top<g.top+8||top+height>g.bottom-8)continue;
  const dx=left+width/2-px,dy=top+height/2-py;
  if(Math.abs(dy)<34&&Math.abs(dx)<width/2+34)continue;
  const box={left,right:left+width,top,bottom:top+height};
  candidates.push({box,score:Math.hypot(dx,dy)+(dy>0?12:0)});
 }
 candidates.sort((a,b)=>a.score-b.score);
 const selected=AWW_ANNUAL_VIEW.chooseLeaderSlot([...(preferred?[preferred]:[]),...candidates.map(p=>p.box)],fits,connector,leaders);
 if(selected)leaders.push(connector(selected));
 return selected; // Never force text onto a trace; the fixed card retains the value.
}
function drawEquityExtremes(c,m,g,x){
 m.equityHitsCurve=equityCurveObstacles(m,g,x);const marks=[];
 equityEntries(m).forEach(({p,i})=>{
  const ps=m.series[i].points,r=m.seriesRanges[i],{stats,mae}=m.windowPerformance?.performance[i]||p;
  for(const [kind,eventDate,percent]of [['DD',stats.troughDate,stats.maxDrawdown],['MAE',mae?.date,mae?.percent]]){
   if(!eventDate||!(percent<0)||(p.key==='buyHold'&&kind==='MAE'))continue;
   // Same containing weekly sample as before; preserve the daily statistic.
   let a=0,b=ps.length;while(a<b){const mid=(a+b)>>1;if(ps[mid].date<eventDate)a=mid+1;else b=mid;}
   const point=ps[a];if(!point||!(point.v>0))continue;
   marks.push({key:p.key,kind,date:eventDate,plotDate:point.date,percent,color:p.color,x:x(point.idx??point.i),y:g.bottom-(Math.log(point.v)-r.min)/(r.max-r.min)*(g.bottom-g.top)});
  }
 });AWW_ANNUAL_VIEW.drawEquitySymbols(c,m,g,marks);
}

// Free cursor level: display geometry only. Unlike a series value, this follows
// the pointer vertically so a wick's high/low can be read on mouse or touch.
function drawLevelHover(c,m,g,primary,secondary,hasSecondary,primaryLeft){
 m.levelHoverLabels=[];m.cursorDrawdownLabel=null;
 const pointer=state.cursor;
 if(m.performance||state.hover===null||pointer?.panel!==m.id||pointer.x<g.left||pointer.x>g.right||pointer.y<g.top||pointer.y>g.bottom)return;
 const yy=pointer.y,inside=compact(),height=18;
 c.save();c.font=(inside?'600 10px':'600 11px')+' Segoe UI,Arial,sans-serif';c.textBaseline='middle';c.strokeStyle='rgba(63,94,130,.6)';c.lineWidth=1;c.setLineDash([3,3]);c.beginPath();c.moveTo(g.left,yy);c.lineTo(g.right,yy);c.stroke();c.setLineDash([]);
 function label(s,isLeft){const raw=s.hi-(yy-g.top)/(g.bottom-g.top)*(s.hi-s.lo),value=s.log?Math.exp(raw):raw,text=fmt(value,0)+(m.id==='position'?' %':'');
  const dd=m.kind==='price'&&!isLeft?AWW_ANNUAL_VIEW.cursorDrawdown(m.cursorPeak,value,state.start+state.count,state.dates.length):null,mainFont=c.font,subFont=(inside?'600 9px':'600 10px')+' Segoe UI,Arial,sans-serif';
  // Match the private badge: actual font widths, 5px side padding, common centre.
  let textWidth=c.measureText(text).width;if(dd){c.font=subFont;textWidth=Math.max(textWidth,c.measureText(dd.text).width);c.font=mainFont;}
  const width=Math.ceil(textWidth)+10,bh=dd?32:height;
  const left=isLeft?(inside?g.left+3:Math.max(0,g.left-width-3)):(inside?g.right-width-3:Math.min(g.w-width,g.right+3)),top=Math.max(g.top,Math.min(g.bottom-bh,yy-height/2));
  const tx=dd?left+width/2:left+5;c.fillStyle=inside?'rgba(255,255,255,.4)':'#15356b';c.fillRect(left,top,width,bh);c.fillStyle=inside?'#294d74':'white';c.textAlign=dd?'center':'left';c.fillText(text,tx,top+height/2);m.levelHoverLabels.push({value,text,left,right:left+width,top,bottom:top+height});
  // Light yellow on navy; keep amber on the translucent light inset badge.
  if(dd){c.font=subFont;c.fillStyle=inside?'#cd7a16':'#ffe66d';c.fillText(dd.text,tx,top+25);m.cursorDrawdownLabel={...dd,left,right:left+width,top:top+height,bottom:top+bh};c.font=mainFont;}
 }
 label(primary,primaryLeft);if(hasSecondary)label(secondary,!primaryLeft);
 // One line in the original axis margin; weekday and hour use the candle's UTC date.
 const text=cursorDate(state.dates[state.hover],state.view.tf!=='weekly'),width=c.measureText(text).width+10,xx=Math.max(g.left+width/2,Math.min(g.right-width/2,g.x(state.hover))),dateTop=g.h-24;c.fillStyle='#15356b';c.fillRect(xx-width/2,dateTop,width,18);c.fillStyle='white';c.textAlign='center';c.fillText(text,xx,dateTop+9);c.restore();
}
// Shared calendar geometry aligns Jan 1 across every panel, even when the
// displayed series is daily/weekly within another price timeframe. Interpolate
// a holiday between sessions; never use an arbitrary tick as an annual boundary.
function drawCalendarYears(c,m,g){
 m.yearSeparators=[];c.save();c.strokeStyle=m.kind==='price'?'#b9c7d7':'#d5dbe2';c.lineWidth=1;
 const first=state.times[0],last=state.times.at(-1);
 for(let year=+state.dates[0].slice(0,4);year<=+state.dates.at(-1).slice(0,4);year++){
  const day=year+'-01-01',time=Date.parse(day+'T00:00:00Z');if(time<first||time>last)continue;
  const xx=g.x(N.position(state.times,time));if(xx<g.left||xx>g.right)continue;
  c.beginPath();c.moveTo(xx,g.top);c.lineTo(xx,g.bottom);c.stroke();m.yearSeparators.push({date:day,x:xx});
 }c.restore();
}
// Paint into the canvas (not CSS), so PNG exports retain public attribution.
// Private NAS/PC charts do not receive this watermark.
function drawChartWatermark(c,g){
 const label='aww365.github.io',width=g.right-g.left,height=g.bottom-g.top;
 if(width<=0||height<=0)return;
 c.save();c.globalAlpha=.095;c.fillStyle='#365879';c.textAlign='center';c.textBaseline='middle';
 let size=Math.min(height*.24,width*.11);c.font='600 '+size+'px Segoe UI,Arial,sans-serif';
 size*=Math.min(1,width*.82/Math.max(1,c.measureText(label).width));c.font='600 '+size+'px Segoe UI,Arial,sans-serif';
 c.fillText(label,(g.left+g.right)/2,(g.top+g.bottom)/2);c.restore();
}
function paint(m){
 if(m.riskTitle){const latest=state.start+state.count>=state.dates.length-.01&&state.hover===null,d=state.dates[Math.max(0,Math.min(state.dates.length-1,state.hover??Math.floor(state.start+state.count-1)))],label=latest?m.currentRisk?.label:m.riskRibbon?.find(p=>p[0]===d)?.[1];m.riskTitle.textContent=label?'RI '+label+(latest&&m.currentRisk?.stale?' *':''):'';m.riskTitle.style.color=label?riskIndexStyle(label).ink:'';}
 if(m.ddTitle)m.ddTitle.textContent=state.start+state.count>=state.dates.length-.01&&m.currentDrawdown?.percent<0?'DD en cours '+fmt(m.currentDrawdown.percent,2)+' %':'';
 m.axisTextBoxes=[];m.insetAxisWidth=0;
 const canvas=m.canvas,w=canvas.clientWidth,h=canvas.clientHeight;if(!w||!h)return;const ratio=Math.min(devicePixelRatio||1,3);if(canvas.width!==Math.round(w*ratio)||canvas.height!==Math.round(h*ratio)){canvas.width=Math.round(w*ratio);canvas.height=Math.round(h*ratio);}const c=canvas.getContext('2d');c.setTransform(ratio,0,0,ratio,0,0);c.clearRect(0,0,w,h);
 const small=w<600,inside=compact(),left=inside?10:m.performance?24:68,right=inside?w-10:w-(m.performance?equityMargin(m,w):79),top=(m.performance||m.h4Periods)?48:16,bottom=h-(m.dca?82:30)-(m.riskRibbon?16:0),width=right-left,height=bottom-top;if(width<10||height<10)return;
 const x=i=>left+(i-state.start+.5)/state.count*width,at=i=>state.dates[Math.max(0,Math.min(state.dates.length-1,Math.floor(i)))],end=at(state.start+state.count-1),hasLast=state.start+state.count>=state.dates.length-.1;
 const candles=(m.candles||[]).filter(r=>r.i>=state.start-1&&r.i<=state.start+state.count),all=m.series.map(s=>({...s,visible:getSlice(s)}));
 const primary=scale([...all.filter(s=>s.axis!=='secondary'&&!(m.kind==='price'&&s.key==='close')).flatMap(s=>s.visible.map(p=>p.v)),...candles.flatMap(r=>[r.low,r.high]),...(m.kind!=='price'?all.filter(s=>s.axis!=='secondary').flatMap(s=>s.visible.map(p=>p.v)):[])],m.kind==='price'?true:m.log,m.zero);
 if(m.kind==='price'){const space=(primary.hi-primary.lo)*.055;primary.lo-=space;primary.hi+=space;}
 if(m.kind==='price'&&m.yZoom){const mid=(primary.hi+primary.lo)/2,half=(primary.hi-primary.lo)*m.yZoom/2;primary.lo=mid-half;primary.hi=mid+half;}
 if(m.id==='position'){primary.lo=-110;primary.hi=110;primary.log=false;}
 const secondary=scale(all.filter(s=>s.axis==='secondary').flatMap(s=>s.visible.map(p=>p.v)),false,false),yOf=(v,s)=>top+(s.hi-(s.log?Math.log(v):v))/(s.hi-s.lo)*height,y=v=>yOf(v,primary),sy=v=>yOf(v,secondary);
 m.geom={left,right,top,bottom,width,x,w,h,insetAxes:inside};
 if(m.id==='valuation'){c.save();c.fillStyle='#a0c0e0';c.fillRect(0,0,w,h);c.fillStyle='#f5f7fa';c.fillRect(left,top,width,height);c.strokeStyle='#7298ba';c.lineWidth=1;c.strokeRect(left-.5,top-.5,width+1,height+1);c.restore();}
 AWW_ANNUAL_VIEW.drawObservationGaps(c,m,m.geom,x,pos,true);
 if(m.performance)m.seriesRanges=equityRanges(m,s=>all[m.series.indexOf(s)].visible,state.start,state.start+state.count-1);c.font=(small?'700 10px':'600 11px')+' Segoe UI,Arial,sans-serif';c.lineWidth=1;
 const hasSecondary=all.some(s=>s.axis==='secondary'),primaryLeft=hasSecondary&&m.id==='ad';
 const ticksFor=s=>(m.id==='position'?[-100,-50,0,50,100]:AWW_ANNUAL_VIEW.roundTicks(s.log?Math.exp(s.lo):s.lo,s.log?Math.exp(s.hi):s.hi,5,s.log,m.zero?[0]:[])).map(v=>({v,y:yOf(v,s)}));
 m.axisTicks=ticksFor(primary);
 m.axisLabelLayout=[];
 // Exposure labels sit towards the inside of the +/-100 plateaus, not on
 // the coloured stroke. Keep the grid at its exact percentage coordinates.
 function axis(s,isLeft){c.save();c.textAlign=inside?(isLeft?'left':'right'):(isLeft?'right':'left');c.globalAlpha=inside?.7:1;
  if(!m.performance)for(const tick of ticksFor(s)){const exposure=inside&&m.id==='position',yy=exposure?(tick.v===-100?bottom+8:tick.y+(tick.v===100?13:tick.v===50?8:4)):inside?Math.max(top+11,Math.min(bottom-3,tick.y+4)):tick.y+4;
   c.fillStyle=m.id==='valuation'?'#234561':'#59718a';AWW_ANNUAL_VIEW.axisText(c,m,m.geom,fmt(tick.v,0)+(m.id==='position'?' %':''),inside?(isLeft?left+4:right-4):(isLeft?left-6:right+6),yy,inside?(isLeft?'left':'right'):(isLeft?'right':'left'),{value:tick.v,lineY:tick.y});m.axisLabelLayout.push({value:tick.v,y:yy,lineY:tick.y});
  }c.restore();}
 m.gridTicks=['ad','hl'].includes(m.id)&&hasSecondary?ticksFor(secondary):m.axisTicks;
 if(!m.performance)for(const tick of m.gridTicks){c.strokeStyle='#e7eef5';c.beginPath();c.moveTo(left,tick.y);c.lineTo(right,tick.y);c.stroke();}if(m.performance)drawEquityAxes(c,m,m.geom);else axis(primary,primaryLeft);if(hasSecondary)axis(secondary,!primaryLeft);if(m.h4Periods)AWW_ANNUAL_VIEW.equityBaseLabel(c,m,m.geom,y(100));
 // Fixed ticks show complete years in every timeframe; the cursor retains date/time.
 c.textAlign='center';const ticks=Math.max(2,Math.floor(width/(small?90:120))),seen=new Set();for(let j=0;j<=ticks;j++){const i=Math.min(state.dates.length-1,Math.floor(state.start+(state.count-1)*j/ticks)),d=at(i);const label=d.slice(0,4);if(!seen.has(label)){c.fillStyle=m.id==='valuation'?'#234561':'#59718a';c.fillText(label,Math.max(left+20,Math.min(right-23,x(i))),m.performance&&inside?bottom+26:m.id==='position'&&inside?h-4:h-8);seen.add(label);}}
 c.save();c.beginPath();c.rect(left,top,width,height);c.clip();
 if(['price-ndx','position','equity'].includes(m.id))drawEquityExposure(c,m,m.geom,x,state.panels.find(p=>p.id==='position')?.series[0].points||[]);
 drawChartWatermark(c,m.geom);drawCalendarYears(c,m,m.geom);
 for(const z of visibleZones(m.zones,end)){const a=x(pos(z.from)),b=x(pos(z.to));if(b<left||a>right)continue;c.fillStyle=z.shade;c.fillRect(a,z.lane==='lower'?top+height/2:top,b-a,z.lane==='lower'?height/2:height);if(Number.isFinite(z.a)&&Number.isFinite(z.b)){c.strokeStyle=z.color;c.setLineDash([]);c.beginPath();c.moveTo(a,y(z.a));c.lineTo(b,y(z.b));c.stroke();}if(hasSecondary&&Number.isFinite(z.priceA)&&Number.isFinite(z.priceB)){c.strokeStyle=z.color;c.setLineDash([4,3]);c.beginPath();c.moveTo(a,sy(z.priceA));c.lineTo(b,sy(z.priceB));c.stroke();}c.setLineDash([]);}
 if(m.zero){c.strokeStyle='#7495ba';c.setLineDash([3,3]);c.beginPath();c.moveTo(left,y(0));c.lineTo(right,y(0));c.stroke();c.setLineDash([]);}
 if(m.h4Lines)paintH4Layer(c,m,m.geom,pen=>drawH4Lines(pen,m,m.geom,x,y,end));
 for(const s of all){if(m.performance&&equityView.hidden.has(s.key))continue;if(m.kind==='price'&&s.key==='close')continue;const range=m.performance?m.seriesRanges[all.indexOf(s)]:null,yy=range?(v=>bottom-(Math.log(v)-range.min)/(range.max-range.min)*height):s.axis==='secondary'?sy:y;
  c.strokeStyle=s.color;c.fillStyle=s.color;c.lineWidth=s.width||1.35;c.setLineDash(s.dash?[4,3]:[]);c.beginPath();let prev=null;
  for(let j=0;j<s.visible.length;j++){const p=s.visible[j];if(!Number.isFinite(p.v)||primary.log&&s.axis!=='secondary'&&p.v<=0){prev=null;continue;}const xx=x(p.i),py=yy(p.v);
   if(s.bar){const neighbor=s.visible[j+1]||s.visible[j-1],spacing=neighbor?Math.abs(x(neighbor.i)-xx):width/state.count,bw=Math.min(24,Math.max(1.5,spacing*.78));c.fillStyle=p.v>=0?s.positiveColor||s.color:s.negativeColor||'#d64564';c.fillRect(xx-bw/2,Math.min(py,yy(0)),bw,Math.max(1,Math.abs(py-yy(0))));}
   else{if(prev&&(!s.gap||Date.parse(p.date)-Date.parse(prev.date)<=s.gap)){if(s.signed){c.stroke();c.beginPath();c.strokeStyle=p.v>=0?'#13846c':'#c14d5b';c.moveTo(x(prev.i),yy(prev.v));}if(s.step)c.lineTo(xx,yy(prev.v));c.lineTo(xx,py);}else c.moveTo(xx,py);prev=p;}
  }if(!s.bar)c.stroke();c.setLineDash([]);
 }
 if(m.kind==='price'){
  const bw=Math.max(.8,Math.min(15,width/state.count*.68));for(const r of candles){const xx=x(r.i),up=r.close>=r.open;c.strokeStyle=r.provisional?'#b57312':up?'#242a32':'#bc4657';c.fillStyle=up?'white':'#e78694';c.lineWidth=1;c.setLineDash(r.provisional?[2,2]:[]);c.beginPath();c.moveTo(xx,y(r.high));c.lineTo(xx,y(r.low));c.stroke();const py=Math.min(y(r.open),y(r.close)),ph=Math.max(1,Math.abs(y(r.close)-y(r.open)));c.fillRect(xx-bw/2,py,bw,ph);if(r.boost){c.strokeStyle='#198754';c.lineWidth=2;}c.strokeRect(xx-bw/2,py,bw,ph);}c.setLineDash([]);c.lineWidth=1;
 }
 AWW_ANNUAL_VIEW.drawYtd(c,m,m.geom,true);
 m.tpLevelLayout=[];
 if(m.id==='ad'||m.id==='hl'){drawDowKey(c,m,m.geom);drawDivergenceFrames(c,m,m.geom,x,end);}
 {
  drawADRegimeMarkers(c,m,{left,right,top,bottom},x,end);
  for(const s of m.segments){if(s.knownAt>end||s.to<at(state.start)||s.from>end)continue;const a=pos(s.from),b=pos(s.to),last=Math.min(b,state.start+state.count-.5),value=s.a+(s.b-s.a)*(last-a)/(b-a||1);c.strokeStyle=s.color;c.setLineDash(s.dash?[3,3]:[]);c.beginPath();c.moveTo(x(a),y(s.a));c.lineTo(x(last),y(value));c.stroke();}c.setLineDash([]);
  const candlePixels=candles.map(r=>({left:x(r.i)-Math.max(1,width/state.count*.4),right:x(r.i)+Math.max(1,width/state.count*.4),top:y(r.high),bottom:y(r.low)}));
  const frozen=m.sliderMarkers;if(frozen&&end>frozen.asOf)frozen.asOf=end;
  const annotationEnd=frozen?.asOf||end;
  const items=m.markers.filter(mark=>mark.knownAt<=annotationEnd).map(mark=>({mark,outcome:mark.outcome||null,i:pos(mark.date),x:x(pos(mark.date)),y:y(mark.value)})).filter(p=>(p.i>=state.start&&p.i<state.start+state.count||frozen?.placements.has(p.mark))&&Number.isFinite(p.y));
  m.markerItems=items;
  // Historical TP levels are supplied by the export; never derive a target here.
  // Keep the stroke even if the collision solver suppresses a crowded caption.
  for(const p of items){if(p.mark.shape!=='tp'||!Number.isFinite(p.mark.triggerValue))continue;
   const yy=y(p.mark.triggerValue),a=Math.max(left,p.x-36),b=Math.min(right,p.x+36);if(yy<top||yy>bottom||b<=a)continue;
   c.save();c.strokeStyle=p.mark.color;c.lineWidth=1.2;c.setLineDash([3,3]);c.beginPath();c.moveTo(a,yy);c.lineTo(b,yy);c.stroke();c.restore();
   m.tpLevelLayout.push({date:p.mark.date,value:p.mark.triggerValue,executionValue:p.mark.executionValue,left:a,right:b,y:yy});
  }
  m.currentRiskLayout=null;
  if(!compact()&&m.currentRisk&&m.currentRisk.asOf<=end&&pos(m.currentRisk.asOf)>=state.start){
   const label='RI · '+m.currentRisk.label+(m.currentRisk.stale?' *':''),w=c.measureText(label).width+14,h=19;
   const obstacles=[...candlePixels,...(m.axisTextBoxes||[]),...(m.ytdLayout?[m.ytdLayout]:[])];
   for(let cy=top+28;cy<bottom-h;cy+=23){
    const box={left:right-w-8,right:right-8,top:cy,bottom:cy+h};
    if(obstacles.some(a=>box.left<a.right+4&&box.right>a.left-4&&box.top<a.bottom+4&&box.bottom>a.top-4))continue;
    c.save();c.fillStyle=riskIndexStyle(m.currentRisk.label).fill;c.fillRect(box.left,box.top,w,h);c.strokeStyle=riskIndexStyle(m.currentRisk.label).border;c.strokeRect(box.left+.5,box.top+.5,w-1,h-1);c.fillStyle=riskIndexStyle(m.currentRisk.label).ink;c.textAlign='center';c.fillText(label,(box.left+box.right)/2,box.top+13);c.restore();m.currentRiskLayout=box;break;
   }
  }
  m.markerLayout=sliderMarkerLayout(m,items,[...candlePixels,...(m.axisTextBoxes||[]),...(m.ytdLayout?[m.ytdLayout]:[]),...(m.currentRiskLayout?[m.currentRiskLayout]:[])],{left,right,top,bottom},s=>c.measureText(s).width,state.count<650);
  for(const p of m.markerLayout){const mark=p.mark,xx=p.center,tip=p.tip,sign=p.sign;
   c.strokeStyle=mark.color;c.lineWidth=1;c.setLineDash([2,3]);c.globalAlpha=.55;c.beginPath();c.moveTo(p.x,Math.max(top,Math.min(bottom,p.y)));c.lineTo(xx,tip-sign*3);c.stroke();c.globalAlpha=1;c.setLineDash(mark.provisional?[2,2]:[]);
   drawMarkerSymbol(c,mark,xx,tip+sign*5);
   if(p.caption){const baseline=sign>0?tip+25:p.box.top+11,extra=(p.outcome?14:0)+(mark.risk?14:0);c.fillStyle=mark.risk?riskIndexStyle(mark.risk).fill:p.outcome?.fill||'#ffffffdf';c.fillRect(p.box.left,baseline-10,p.box.right-p.box.left,14+extra);c.fillStyle=mark.risk?riskIndexStyle(mark.risk).ink:p.outcome?.ink||mark.color;c.textAlign='center';c.fillText(mark.label,xx,baseline);
    if(mark.risk)c.fillText('RI · '+mark.risk,xx,baseline+14);
    if(p.outcome)c.fillText('Top-bottom '+fmt(p.outcome.percent,1)+' %',xx,baseline+14+(mark.risk?14:0));
   }
  }
  if(m.h4Lines)paintH4Layer(c,m,m.geom,pen=>drawH4LineLabels(pen,m,m.geom,candlePixels));
  // The 30% frame is a price-chart aid, regardless of signal/regime colour.
  // Transparent interior: preserve candles and keep capital DD/MAE unchanged.
  m.correctionLabelLayout=[];
  for(const dd of m.drawdowns||[]){
   if(dd.confirmed>end)continue;const xx=x(Math.ceil(pos(dd.date)));if(xx<left||xx>right)continue;
   const label=fmt(dd.percent,1)+' %',framed=dd.percent<-30,w=c.measureText(label).width+10;
   const cx=Math.max(left+w/2+2,Math.min(right-w/2-2,xx));let yy=null;
   const obstacles=[...candlePixels,...(m.axisTextBoxes||[]),...(m.markerLayout||[]).map(p=>p.box),...(m.correctionLabelLayout||[]).map(p=>({left:p.x,right:p.x+p.w,top:p.y,bottom:p.y+p.h})),...(m.ytdLayout?[m.ytdLayout]:[]),...(m.currentRiskLayout?[m.currentRiskLayout]:[])];
   for(const sign of [1,-1]){for(let gap=25;gap<height;gap+=19){const py=y(dd.value)+sign*gap,b={left:cx-w/2,right:cx+w/2,top:py-12,bottom:py+4};
    if(b.top<top+2||b.bottom>bottom-2)break;
    if(!obstacles.some(a=>b.left<a.right+4&&b.right>a.left-4&&b.top<a.bottom+4&&b.bottom>a.top-4)){yy=py;break;}
   }if(yy!==null)break;}if(yy===null)continue;
   c.save();c.strokeStyle='#97a7b8';c.lineWidth=.7;c.setLineDash([2,3]);c.beginPath();c.moveTo(xx,y(dd.value));c.lineTo(cx,yy>y(dd.value)?yy-13:yy+5);c.stroke();c.restore();
   c.fillStyle=dd.tone==='r'?'#c14d5b':dd.tone==='b'?'#1675c5':'#c47b21';
   if(framed){c.strokeStyle=c.fillStyle;c.lineWidth=1;c.setLineDash([]);c.strokeRect(cx-w/2,yy-12,w,16);}
   c.textAlign='center';c.fillText(label,cx,yy);m.correctionLabelLayout.push({date:dd.date,percent:dd.percent,framed,x:cx-w/2,y:yy-12,w,h:16});
  }

  // Public check only: no reference name, forecast or trigger explanation.
  if(m.referenceMark){const p=m.referenceMark,xx=x(pos(p.date)),yy=y(p.value);
   if(xx>=left&&xx<=right&&yy>=top&&yy<=bottom){c.save();c.strokeStyle='#15356b';c.lineWidth=1.6;c.setLineDash([]);c.beginPath();c.moveTo(xx-4,yy-2);c.lineTo(xx,yy+2);c.lineTo(xx+6,yy-5);c.stroke();c.restore();}
  }
 }
 c.restore();
 if(m.h4Lines)AWW_ANNUAL_VIEW.drawActivatedLevels(c,m,m.geom,m.h4Lines.filter(l=>l.code==='AC'&&l.knownAt===state.dates.at(-1)).map(l=>({id:l.id,left:x(pos(l.ends[0][0])),right:x(pos(l.ends[1][0])),lower:[l.ends[0][2],l.ends[1][2]],upper:[l.ends[0][3],l.ends[1][3]],level:l.labelAt[1],barStep:x(1)-x(0),color:l.color,levelColor:l.levelColor})),y);
 if(m.h4Lines)paintH4Layer(c,m,m.geom,pen=>{for(const paint of m.h4LabelPaints||[])paint(pen);});
 if(m.id==='valuation')AWW_ANNUAL_VIEW.drawValuationLevels(c,m,m.geom,all.map(s=>{const p=s.visible.findLast(p=>p.i>=state.start&&p.i<=state.start+state.count-1&&Number.isFinite(p.v));return p?{key:s.key,v:p.v,color:s.color,py:y(p.v)}:null;}).filter(Boolean));
 if(m.performance){for(const ref of AWW_ANNUAL_VIEW.activeReferences(m,equityView.hidden)){const r=m.seriesRanges[ref.axis];AWW_ANNUAL_VIEW.drawReference(c,{lqq:ref,lqqWindow:ref.window},m.geom,x,v=>bottom-(Math.log(v)-r.min)/(r.max-r.min)*height,state.start,state.start+state.count-1);}if(m.lqq&&!equityView.hidden.has('lqq')&&!equityView.hidden.has('sys2')){const r=m.seriesRanges[2];AWW_ANNUAL_VIEW.drawReference(c,m,m.geom,x,v=>bottom-(Math.log(v)-r.min)/(r.max-r.min)*height,state.start,state.start+state.count-1);}drawEquityExtremes(c,m,m.geom,x);}
 if(m.h4Periods){const from=state.dates[Math.max(0,Math.ceil(state.start))],to=state.dates[Math.min(state.dates.length-1,Math.floor(state.start+state.count-1))];m.h4WindowPerformance=AWW_ANNUAL_VIEW.h4WindowStats(m.series,m.h4Periods,from,to);m.h4WindowKey=from+'|'+to;}
 if(m.h4Periods)AWW_ANNUAL_VIEW.drawH4Extremes(c,m,m.geom,x,y,pos);
 if(m.id==='equity')AWW_ANNUAL_VIEW.drawEndGains(c,m,m.geom,all.flatMap((s,i)=>m.performance&&equityView.hidden.has(s.key)?[]:[{key:s.key,color:s.color,points:s.visible,base:m.performance?m.equityBases[i]?.value:undefined,y:m.performance?v=>bottom-(Math.log(v)-m.seriesRanges[i].min)/(m.seriesRanges[i].max-m.seriesRanges[i].min)*height:y}]),x,state.start,state.start+state.count-1);
 if(m.dca){
  // Inset labels stay at the left so the latest (rightmost) state remains visible.
  const railLabel=(label,yy)=>{c.save();c.textAlign=inside?'left':'right';c.fillStyle='#52677c';if(inside){c.strokeStyle='rgba(255,255,255,.7)';c.lineWidth=2;c.strokeText(label,left+4,yy);}c.fillText(label,inside?left+4:left-5,yy);c.restore();};
  const rails=[['AD cum.',m.ribbons?.ad],['NH−NL',m.ribbons?.hl]];rails.forEach(([label,zs],j)=>{const yy=bottom+9+j*12;c.fillStyle='#eaf0f5';c.fillRect(left,yy,width,7);for(const z of visibleZones(zs,end)){const a=Math.max(left,x(pos(z.from))),b=Math.min(right,x(pos(z.to)));if(b>a){c.fillStyle=z.color+'88';c.fillRect(a,yy,b-a,7);}}railLabel(label,yy+7);});
  const yy=bottom+34;let segment=null;const flush=()=>{if(!segment)return;const a=Math.max(left,segment.a),b=Math.min(right,segment.b);if(b<=a)return;c.fillStyle=segment.color;c.fillRect(a,yy,b-a,12);if(b-a>27){c.fillStyle=segment.label==='M'?'#285337':'white';c.textAlign='center';c.fillText(segment.label,(a+b)/2,yy+10);}};
  for(const [d,label,color] of m.dca){const i=pos(d);if(i<state.start-1||i>state.start+state.count)continue;const a=x(i)-width/state.count/2,b=a+width/state.count;if(segment?.label===label)segment.b=b;else{flush();segment={a,b,label,color};}}flush();
  for(const [d] of m.bams||[]){const xx=x(pos(d));if(xx>=left&&xx<=right){c.fillStyle='#f0cc25';c.fillRect(xx-2,yy,4,12);}}
  railLabel('DCA',yy+9);
 }
 if(m.riskRibbon){
  const yy=bottom+(m.dca?50:4);c.save();c.beginPath();c.rect(left,yy,width,11);c.clip();m.riskRibbonLayout=[];let segment=null;
  const flush=()=>{if(!segment)return;const a=x(segment.from)-width/state.count/2,b=x(segment.to)+width/state.count/2,tone=riskIndexStyle(segment.label);c.fillStyle=tone.fill;c.fillRect(a,yy,b-a,11);if(b-a>65){c.fillStyle=tone.ink;c.font='bold 8px Arial,sans-serif';c.textAlign='center';c.fillText(segment.label||'—',(a+b)/2,yy+9);}m.riskRibbonLayout.push({label:segment.label,x:a,y:yy,w:b-a,h:11});};
  for(const [d,label] of m.riskRibbon){const i=pos(d);if(i<state.start-1||i>state.start+state.count)continue;if(segment?.label===label)segment.to=i;else{flush();segment={label,from:i,to:i};}}flush();c.restore();
  c.save();c.fillStyle='#52677c';c.textAlign=inside?'left':'right';c.font='9px Arial,sans-serif';c.fillText('RI',inside?left+4:left-5,yy+9);c.restore();
 }
 if(state.hover!==null){const xx=x(state.hover);if(xx>=left&&xx<=right){c.strokeStyle='#567ba0';c.setLineDash([3,3]);c.beginPath();c.moveTo(xx,top);c.lineTo(xx,bottom);c.stroke();c.setLineDash([]);}}
 if(m.performance){
  drawEquityHover(c,m,m.geom,x,state.hover,state.dates[state.hover]);
  AWW_ANNUAL_VIEW.drawPeriods(c,m,m.geom,x,d=>Math.ceil(pos(d)),state.dates[state.hover],equityEntries(m).length>0);
 }
 if(m.h4Periods)AWW_ANNUAL_VIEW.drawH4Periods(c,m,m.geom,x,d=>Math.ceil(pos(d)),at(state.start-.5),at(state.start+state.count-.5),state.dates[state.hover]);
 drawLevelHover(c,m,m.geom,primary,secondary,hasSecondary,primaryLeft);
 AWW_ANNUAL_VIEW.drawYtd(c,m,m.geom);
 updateLatestButton(m);
 m.metrics.replaceChildren();if(m.stats&&!m.performance&&!m.h4Periods){const s=m.stats;m.metrics.append(textNode('span',Number.isFinite(s.cagr)?(m.cagrLabel||'CAGR')+' '+fmt(s.cagr)+' %':'Perf. '+fmt(s.cumulativeReturnPct)+' %'),textNode('span','○ MDD '+fmt(s.maxDrawdown??s.maxDrawdownPct)+' %'),textNode('span','Période · '+date(s.from)+' — '+date(s.to)));}
 if(m.riskRibbon&&!compact()){const d=at(state.hover??Math.floor(state.start+state.count-1)),r=m.riskRibbon.find(p=>p[0]===d);if(r)m.metrics.append(textNode('span','RI · '+(r[1]||'indisponible')));}
 if(hasLast&&m.kind==='price'){
  for(const r of m.readouts||[]){const span=textNode('span',r.text);span.style.color=r.color;m.metrics.append(span);}
 }
 if(m.id==='equity')AWW_ANNUAL_VIEW.equityBaseLabel(c,m,m.geom,null,true);
 if(m.performance)drawEquityCard(c,m,m.geom);
 if(m.h4Periods)AWW_ANNUAL_VIEW.drawH4Card(c,m,m.geom,state.dates[Math.max(0,Math.ceil(state.start))],state.dates[Math.min(state.dates.length-1,Math.floor(state.start+state.count-1))],{compact:compact(),publicView:true});
}
/** Describe this reader's actual handlers, not the PC's richer gestures.
 * Public charts pan/zoom time; only price charts resize via the right axis.
 * No rectangle zoom, vertical panning or double-click reset exists here.
 */
function chartGestureHelp(m){
 const rows=['Survol : lire la date et les valeurs.','Glisser : parcourir les dates.','Molette : zoomer dans le temps.'];
 if(m.kind==='price')rows.push('Axe droit : glisser pour ajuster les prix.');
 else if(m.id==='position')rows.push('Échelle : graduations fixes.');
 else if(m.performance)rows.push('Échelles : ajustement automatique selon les courbes cochées.');
 else if(m.id==='ad'||m.id==='hl')rows.push((m.id==='ad'?'A/D':'NH−NL')+' : échelle automatique.','Dow : échelle automatique.');
 else rows.push('Échelle : ajustement automatique.');
 return rows.join('\n');
}
function bind(m){const el=m.canvas;
 el.addEventListener('aww-chart-capture',()=>{state.hover=null;state.cursor=null;paint(m);});
 el.title='';el.dataset.chartHelp=chartGestureHelp(m);
 const xy=e=>{const r=el.getBoundingClientRect();return {x:e.clientX-r.left,y:e.clientY-r.top};};
 const fraction=x=>Math.max(0,Math.min(1,(x-m.geom.left)/m.geom.width));
 el.addEventListener('wheel',e=>{if(!m.geom)return;e.preventDefault();beginViewAction('wheel');zoom(Math.exp(Math.max(-200,Math.min(200,e.deltaY))*.002),fraction(xy(e).x));clearTimeout(viewHistory.timer);viewHistory.timer=setTimeout(endViewAction,400);},{passive:false});
 el.addEventListener('pointerdown',e=>{if(!m.geom||e.button!==0)return;beginViewAction('pointer');const p=xy(e);pointers.set(e.pointerId,p);el.setPointerCapture(e.pointerId);if(pointers.size===1)gesture={panel:m.id,x:p.x,y:p.y,start:state.start,count:state.count,yZoom:m.yZoom||1,mode:m.kind==='price'&&p.x>m.geom.right?'scale':null,moved:false};else if(pointers.size===2){const [a,b]=[...pointers.values()];gesture={panel:m.id,start:state.start,count:state.count,mode:'pinch',distance:Math.max(1,Math.hypot(a.x-b.x,a.y-b.y)),center:state.start+fraction((a.x+b.x)/2)*state.count,moved:true};}});
 el.addEventListener('pointermove',e=>{if(!m.geom)return;const p=xy(e);if(!pointers.has(e.pointerId)){if(e.pointerType==='mouse'){state.cursor={panel:m.id,...p};state.hover=Math.max(0,Math.min(state.dates.length-1,Math.round(state.start+fraction(p.x)*state.count-.5)));schedule();}return;}
  pointers.set(e.pointerId,p);if(!gesture||gesture.panel!==m.id)return;
  if(pointers.size===2){e.preventDefault();const [a,b]=[...pointers.values()],dist=Math.max(1,Math.hypot(a.x-b.x,a.y-b.y)),count=gesture.count*gesture.distance/dist,anchor=fraction((a.x+b.x)/2);Object.assign(state,N.clamp(gesture.center-count*anchor,count,state.dates.length));gesture.moved=true;sync();return;}
  if(gesture.mode==='pinch')return;const dx=p.x-gesture.x,dy=p.y-gesture.y;if(gesture.mode==='scale'){e.preventDefault();gesture.moved=true;m.yZoom=Math.max(.1,Math.min(10,gesture.yZoom*Math.exp(dy*.008)));schedule();return;}if(!gesture.mode&&Math.max(Math.abs(dx),Math.abs(dy))>7)gesture.mode=e.pointerType==='touch'&&Math.abs(dy)>Math.abs(dx)?'scroll':'pan';
  if(gesture.mode==='pan'){e.preventDefault();gesture.moved=true;state.start=N.clamp(gesture.start-dx/m.geom.width*gesture.count,state.count,state.dates.length).start;state.hover=null;sync();}
 },{passive:false});
 const end=e=>{const p=xy(e);if(gesture&&!gesture.moved&&gesture.mode!=='scroll'){state.cursor={panel:m.id,...p};state.hover=Math.max(0,Math.min(state.dates.length-1,Math.round(state.start+fraction(p.x)*state.count-.5)));schedule();}pointers.delete(e.pointerId);if(el.hasPointerCapture(e.pointerId))el.releasePointerCapture(e.pointerId);if(!pointers.size){gesture=null;endViewAction();}};
 el.addEventListener('pointerleave',e=>{if(e.pointerType==='mouse'&&!pointers.size){state.hover=null;schedule();}});
 el.addEventListener('pointerup',end);el.addEventListener('pointercancel',e=>{pointers.delete(e.pointerId);gesture=null;if(!pointers.size)endViewAction();});el.addEventListener('lostpointercapture',e=>{pointers.delete(e.pointerId);if(!pointers.size){gesture=null;endViewAction();}});
 el.addEventListener('keydown',e=>{if(['ArrowLeft','ArrowRight','+','=','-','Home','End'].includes(e.key)){e.preventDefault();endViewAction();if(e.key==='+'||e.key==='=')zoomRight(.7);else if(e.key==='-')zoomRight(1.4);else{state.start=e.key==='Home'?0:e.key==='End'?state.dates.length-state.count:state.start+(e.key==='ArrowLeft'?-1:1)*Math.max(1,state.count*.1);sync();}}});
}
function syncViewButtons(){
 for(const [attr,id] of [['index','index'],['timeframe','unit']])document.querySelectorAll('[data-'+attr+']').forEach(b=>{const on=b.dataset[attr]===$(id).value;b.classList.toggle('active',on);b.setAttribute('aria-pressed',String(on));});
}
$('index').onchange=()=>loadView(false,null,true);
document.querySelectorAll('[data-index]').forEach(b=>b.onclick=()=>{if($('index').value===b.dataset.index)return;$('index').value=b.dataset.index;$('index').onchange();});
document.querySelectorAll('[data-timeframe]').forEach(b=>b.onclick=()=>{if($('unit').value===b.dataset.timeframe)return;$('unit').value=b.dataset.timeframe;return $('unit').onchange();});
$('unit').onchange=async()=>{
 const previous=state.view?.tf,next=$('unit').value;
 const periodYears=AWW_ANNUAL_VIEW.entryPeriod(previous,next);
 // Apply the horizon before the first paint/history entry, inside loadView's
 // request guard; an older async selection cannot reframe a newer one.
 scenarios();await loadView(false,periodYears,next==='h4'&&previous!=='h4');
};
$('scenario').onchange=()=>loadView();
$('system-1').onclick=()=>setSystem('sys1');$('system-2').onclick=()=>setSystem('sys2');
$('since-year').onchange=()=>sinceYear($('since-year').value);$('end-year').onchange=()=>endAtYear($('end-year').value);
document.querySelectorAll('[data-years]').forEach(b=>b.onclick=()=>years(b.dataset.years));$('zoom-in').onclick=()=>zoomRight(.7);$('zoom-out').onclick=()=>zoomRight(1.4);
$('view-back').onclick=()=>moveViewHistory(-1);$('view-forward').onclick=()=>moveViewHistory(1);
$('apply').onclick=()=>{endViewAction();const from=$('from').value,to=$('to').value,range=N.windowFor(state.dates,from,to);if(!from||!to||from>to||!range){setStatus('Choisis deux dates dans l’historique disponible.');return;}Object.assign(state,range);state.hover=null;setStatus('');sync();};
// Installation help belongs to iPhone Safari, not to the installed app.
// Both iOS's legacy flag and the standard display mode must hide it.
function shouldShowIOSInstallHelp(ua,standalone,displayStandalone){
 return /iPhone|iPod/i.test(ua)&&/Safari/i.test(ua)&&!/(CriOS|FxiOS|EdgiOS|OPiOS)/i.test(ua)&&!standalone&&!displayStandalone;
}
const standaloneDisplay=typeof matchMedia==='function'?matchMedia('(display-mode: standalone)'):null;
function syncIOSInstallHelp(){
 const help=$('ios-install-help');
 if(help)help.hidden=!shouldShowIOSInstallHelp(navigator.userAgent||'',navigator.standalone===true,standaloneDisplay?.matches===true);
}
syncIOSInstallHelp();standaloneDisplay?.addEventListener?.('change',syncIOSInstallHelp);addEventListener('pageshow',syncIOSInstallHelp);
// Only history moves on resize. Both year selectors remain next to Afficher
// in the blue header, leaving the phone's eight zoom buttons full width.
// Same fixed-height banner contract as the private application. Measure once
// per resize using the real controls; no clone, recreated handlers or new IDs.
function placeResponsiveControls(){
 if(!document.querySelector)return;
 const header=document.querySelector('header'),main=document.querySelector('main'),controls=$('controls');
 if(!header?.getBoundingClientRect||!main?.prepend||!controls?.classList)return;
 const previousFold=header.dataset.folded,previousOpen=controls.open;
 let fold=compact();
 if(!fold){
  header.dataset.folded='false';
  header.append(controls);controls.open=true;controls.classList.add('controls-measure');
  const css=getComputedStyle(header),brand=$('brand');
  const required=controls.scrollWidth+brand.scrollWidth+$('risk-index-open').offsetWidth+2*parseFloat(css.columnGap||12)+parseFloat(css.paddingLeft)+parseFloat(css.paddingRight);
  controls.classList.remove('controls-measure');fold=required>header.clientWidth;
 }
 const changed=previousFold!==String(fold);
 const navigation=$('mobile-navigation'),quick=$('quick-controls'),site=document.querySelector('.site-controls');
 if(compact()){if(quick.parentElement!==navigation)navigation.append(quick);if(controls.parentElement!==navigation)navigation.append(controls);}
 else {if(quick.parentElement!==site)site.append(quick);if(fold&&controls.parentElement!==main)main.prepend(controls);}
 if(fold){controls.open=changed?false:previousOpen;}
 else controls.open=true;
 header.dataset.folded=String(fold);header.dataset.toolbarReady='true';
}
let mobileHistoryControl;
function placeHistoryControl(){
 const phone=compact();
 if(phone!==mobileHistoryControl){$(phone?'header-history':'quick-controls')[phone?'append':'prepend']($('view-history'));(phone?$('refresh-actions'):$('quick-controls')).append($('coverage'));mobileHistoryControl=phone;}
}
// Diego is the sole help trigger. A modal does not reflow charts; native
// Escape/focus containment also work with a keyboard or VoiceOver.
const riskDialog=$('risk-index-dialog');
$('risk-index-open').onclick=()=>riskDialog.showModal();
$('risk-index-close').onclick=()=>riskDialog.close();
riskDialog.addEventListener('click',e=>{if(e.target===riskDialog){const b=riskDialog.getBoundingClientRect();if(e.clientX<b.left||e.clientX>b.right||e.clientY<b.top||e.clientY>b.bottom)riskDialog.close();}});
placeHistoryControl();placeResponsiveControls();
$('refresh').onclick=()=>location.reload();addEventListener('resize',()=>{syncDirectionText();placeHistoryControl();placeResponsiveControls();schedule();});addEventListener('blur',()=>{gesture=null;pointers.clear();endViewAction();});
// Public price charts always use the semi-logarithmic display.
scenarios();
if(compact())$('controls').open=false;
json('catalog.json').then(c=>{if(c.schemaVersion!==1)throw Error('Version de données incompatible');state.catalog=c;return loadView(true);}).catch(e=>setStatus(e.message));
if('serviceWorker' in navigator)navigator.serviceWorker.register('./sw.js',{updateViaCache:'none'}).catch(()=>{});
})();

/** Explicit user gesture only: export the CURRENT canvas, not the desktop or
 * page. No account/token, upload endpoint or automatic publication. Web Share
 * hands ONLY a PNG to the OS (X when available). Otherwise copy image/png
 * to the clipboard, or download the PNG. A separate X link requires the user
 * to paste/attach that image; URL intents cannot attach an image automatically.
 * Appended unchanged to the public reader; contains no private engine logic.
 */
(function(){
 'use strict';
 if(typeof document==='undefined'||typeof MutationObserver==='undefined')return;
 const charts=document.getElementById('chart-stack')||document.getElementById('charts');if(!charts)return;
 // Styling lives in the application/public CSS: public CSP rejects inline style elements.
 function tell(text,offerX=false,file=null){document.querySelector('.chart-share-note')?.remove();const p=document.createElement('p');p.className='chart-share-note';p.setAttribute('role','status');p.textContent=text;if(file){const a=document.createElement('a'),url=URL.createObjectURL(file);a.href=url;a.download=file.name;a.textContent=' Télécharger le PNG';p.append(a);setTimeout(()=>URL.revokeObjectURL(url),60000);}if(offerX){const a=document.createElement('a');a.href='https://x.com/compose/post';a.target='_blank';a.rel='noopener noreferrer';a.textContent=' Ouvrir X';p.append(a);}document.body.append(p);setTimeout(()=>p.remove(),20000);}
 // Copy the laid-out heading, not h2.textContent: that would concatenate the
 // orange DD with the title and lose its font, colour, spacing and wrapping.
 // DOM Range supplies each visible glyph's real location. No screenshot library,
 // network round-trip or async image decode (which would lose iOS activation).
 function copyHeading(c,header,left,top){
  if(!header)return;
  const walker=document.createTreeWalker(header,NodeFilter.SHOW_TEXT),range=document.createRange();let node;
  while((node=walker.nextNode())){
   const style=getComputedStyle(node.parentElement);
   if(style.visibility==='hidden'||style.display==='none'||node.parentElement.closest('button,[hidden]'))continue;
   c.font=[style.fontStyle,style.fontWeight,style.fontSize,style.fontFamily].join(' ');c.fillStyle=style.color;c.textAlign='left';c.textBaseline='alphabetic';
   const metrics=c.measureText('Mg'),ascent=metrics.fontBoundingBoxAscent||parseFloat(style.fontSize)*.8,descent=metrics.fontBoundingBoxDescent||parseFloat(style.fontSize)*.2;
   for(let i=0;i<node.length;i++){
    range.setStart(node,i);range.setEnd(node,i+1);
    const r=range.getBoundingClientRect();if(!r.width||!r.height)continue;
    c.fillText(node.data[i],r.left-left,r.top-top+(r.height-ascent-descent)/2+ascent);
   }
  }
  // Mobile uses CSS-generated "EU" in place of the long scale caption.
  // It has no text node: copy its visible box as well, without expanding it.
  for(const label of header.querySelectorAll('.equity-controls span')){
   const style=getComputedStyle(label,'::after'),content=style.content;
   if(!content||content==='none'||content==='normal'||style.display==='none')continue;
   const text=content.replace(/^["']|["']$/g,''),r=label.getBoundingClientRect();
   if(!text||!r.width||!r.height)continue;
   c.font=style.font;c.fillStyle=style.color;c.textAlign='left';c.textBaseline='alphabetic';
   const m=c.measureText('Mg'),a=m.fontBoundingBoxAscent||parseFloat(style.fontSize)*.8,d=m.fontBoundingBoxDescent||parseFloat(style.fontSize)*.2;
   c.fillText(text,r.left-left,r.top-top+(r.height-a-d)/2+a);
  }
  // The legend checkboxes are UI controls, not part of the canvas. Keep their
  // visible checked state and accent colour beside their original labels.
  for(const input of header.querySelectorAll('input[type=checkbox]')){
   const r=input.getBoundingClientRect();if(!r.width||!r.height)continue;
   const style=getComputedStyle(input),x=r.left-left,y=r.top-top,w=r.width,h=r.height;
   c.fillStyle=input.checked?(style.accentColor==='auto'?'#245da8':style.accentColor):'#fff';c.fillRect(x,y,w,h);c.strokeStyle=input.checked?c.fillStyle:'#8794a2';c.lineWidth=1;c.strokeRect(x,y,w,h);
   if(input.checked){c.strokeStyle='#fff';c.lineWidth=1.7;c.beginPath();c.moveTo(x+w*.2,y+h*.52);c.lineTo(x+w*.43,y+h*.75);c.lineTo(x+w*.82,y+h*.23);c.stroke();}
  }
 }
 function share(panel,canvas){
  if(!canvas.width||!canvas.height)return;
  // Clear only transient crosshairs (including their +0.00% readout) and flush
  // the displayed frame synchronously. YTD, labels, zoom and curves stay intact.
  canvas.dispatchEvent(new Event('aww-chart-capture'));
  const out=document.createElement('canvas'),r=canvas.getBoundingClientRect(),scale=canvas.width/r.width;
  const header=panel.querySelector('.panel-head,.equity-head')||panel.querySelector('h2'),top=header?.getBoundingClientRect().top??r.top,head=Math.max(0,Math.round((r.top-top)*scale));
  out.width=canvas.width;out.height=canvas.height+head;
  const c=out.getContext('2d');c.fillStyle='#fff';c.fillRect(0,0,out.width,out.height);
  c.save();c.scale(scale,scale);copyHeading(c,header,r.left,top);c.restore();
  // One bitmap copy at native resolution: no replot, crop or rescaling.
  c.drawImage(canvas,0,head);
  // Synchronous conversion retains iOS's transient user activation for Share.
  const data=atob(out.toDataURL('image/png').split(',')[1]),bytes=Uint8Array.from(data,ch=>ch.charCodeAt(0));
  const name='AWW-'+(panel.classList.contains('price')?'indice':'capital')+'-'+new Date().toISOString().slice(0,10)+'.png';
  const file=new File([bytes],name,{type:'image/png'});
  if(navigator.maxTouchPoints>0&&navigator.canShare?.({files:[file]})&&navigator.share){navigator.share({files:[file]}).catch(e=>{if(e.name!=='AbortError')copyOrDownload();});return;}
  function download(){const url=URL.createObjectURL(file),a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);tell('Image PNG téléchargée. Ajoutez cette image à votre post.',true);}
  // ClipboardItem uses image/png, never writeText: no text-only substitute.
  // Open X only on a second explicit click, after copying has finished. Opening
  // a new tab first can remove focus and make clipboard.write fail in Chrome.
  function copyOrDownload(){if(navigator.clipboard?.write&&typeof ClipboardItem!=='undefined'){
   navigator.clipboard.write([new ClipboardItem({'image/png':file})]).then(()=>tell('Image PNG copiée. Ouvrez X, puis collez-la dans le post (Ctrl+V sur PC).',true,file)).catch(download);
  }else download();}
  copyOrDownload();
 }
 function install(){for(const panel of charts.querySelectorAll('.panel')){
  const canvas=panel.querySelector('canvas'),isCapital=canvas?.id==='canvas-equity'||canvas?.dataset.panel==='equity';
  if(!canvas||(!panel.classList.contains('price')&&!isCapital)||panel.querySelector('.chart-share'))continue;
  const plot=canvas.parentElement,button=document.createElement('button');button.type='button';button.className='chart-share';button.title=navigator.maxTouchPoints>0?'Partager le graphique en image':'Copier le graphique en image';button.setAttribute('aria-label',button.title);button.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="6" width="18" height="15" rx="3"/><path d="m8 6 2-3h4l2 3"/><circle cx="12" cy="13.5" r="3.5"/></svg>';button.onclick=()=>share(panel,canvas);plot.append(button);
 }}
 new MutationObserver(install).observe(charts,{childList:true});install();
})();
